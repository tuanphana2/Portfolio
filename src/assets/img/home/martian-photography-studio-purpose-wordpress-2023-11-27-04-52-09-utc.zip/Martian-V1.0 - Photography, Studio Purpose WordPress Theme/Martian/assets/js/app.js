var MARTIAN = MARTIAN || {};

(function ($) {
    'use strict';

    var $window = $(window),
        $document = $(document);

    /**
     * Selectors we need to work with it.
     * @type {Object}
     */
    var Selectors = {
        $html: $('html'),
        $body: $('body'),
        $header: $('#masthead'),
        $footer: $('#site-footer'),
        $slider: $('.martian-slider.default'),
        $sliderWT: $('.martian-slider.with-thumbnails'),
        $carouselUV: $('.martian-carousel-UV'),
        $carouselUVT: $('.martian-carousel-UVT'),
        $carouselAudio: $('.swiper-slider-audio'),
        $menuContainer: $('#martian-main-menu'),
        $menuToggle: $('#nav-toggle'),
        makeBackground: '.setBackground',
        sliderBackground: '.swiper-slide.makeBackground',
        $skillBar: $('.skill-item > .skill-progress > span'),
        $staticsCounter: $('[data-counter]'),
        postLike: '.ajaxLike',
        lgGallery: '.martian-lightGallery',
        $jfGallery: $('.martian-justified-gallery'),
        lgSingle: '.viewLightbox',
        $teamProfiles: $('.martian-team-profiles'),
        $logoCarousel: $('.martian-logo-carousel'),
        $countdownTimer: $('.martian-countdown-timer'),
        $ajaxForm: $('.martian-ajax-form'),
        $parallaxPanel: $('.parallax-panel'),
        fullscreenVideo: document.querySelectorAll('.martian-fullscreen-video > .martian-fs-video'),
        $isotopeMasonryGallery: $('.mt-isotope-masonry'),
        $isotopeFilterableGallery: $('.mt-filterable-gallery'),
        $beforeAfter: $('.martian-before-after')
    };

    /**
     * Functions those need to run when the document is ready.
     */
    MARTIAN.onReady = function () {
        MARTIAN.Helpers.browserDetect();
        Selectors.$header.after('<div id="masthead-faker"></div>');
        MARTIAN.Plugins.header();
        MARTIAN.Plugins.footer();
        MARTIAN.Plugins.menuToggle();
        MARTIAN.Plugins.mobileMenu();
        MARTIAN.Plugins.mobileMenuHeight();

        // Carousels with Swiper
        if (window.Swiper && window.SwiperRunner) {
            MARTIAN.Plugins.slider();
            MARTIAN.Plugins.sliderWithNav();
            MARTIAN.Plugins.carouselUniversal();
            MARTIAN.Plugins.carouselUniversalWithThumb();
        }

        // Slider Audio
        MARTIAN.Plugins.handleSliderAudio();

        // Backgrounds
        MARTIAN.Helpers.setBackground({
            el: Selectors.makeBackground
        });
        MARTIAN.Helpers.setBackground({
            el: Selectors.sliderBackground,
            css: {
                backgroundSize: 'cover',
                backgroundPosition: 'center center',
                backgroundRepeat: 'no-repeat'
            }
        });

        // Skill bars
        MARTIAN.Plugins.skillBars(Selectors.$skillBar);

        // Ajax Post Like
        MARTIAN.Plugins.ajaxPostLike(Selectors.postLike);

        // Light Galleries
        if ($.fn.lightGallery) {
            // Defaults
            MARTIAN.Plugins.lightGallery(Selectors.lgGallery);

            // Single
            MARTIAN.Plugins.lightGallery(Selectors.lgSingle, {
                selector: 'this',
                download: false,
                counter: false
            });
        }

        // Justified Gallery
        if ($.fn.justifiedGallery) {
            MARTIAN.Plugins.justifiedGallery();
        }

        // Before After
        if ($.fn.beforeAfter) {
            MARTIAN.Plugins.beforeAfter();
        }

        // Parallax Background
        if ($.fn.backgroundParallax) {
            Selectors.$parallaxPanel.backgroundParallax({
                isMobile: false
            });
        }

        // Statics Counter
        MARTIAN.Plugins.staticsCounter(Selectors.$staticsCounter);

        // Team profile Resize
        MARTIAN.Plugins.teamProfileResize();

        // Countdown Timer
        MARTIAN.Plugins.countdownTimer();

        // Handle forms
        MARTIAN.Plugins.ajaxFormManager();

        // Plyr
        if (window.plyr) {
            MARTIAN.Plugins.plyr();
        }

        // Isotope
        if ($.fn.isotope) {
            MARTIAN.Plugins.isotopeMasonryGallery();
            MARTIAN.Plugins.isotopeFilterableGallery();
        }

        // WOW.js init
        if (window.WOW) {
            new WOW().init();
        }
    };

    /**
     * Functions those need to run when the document is load.
     */
    MARTIAN.onLoad = function () {
    };

    /**
     * Functions those need to run when the document is resizing.
     */
    MARTIAN.onResize = function () {
        MARTIAN.Plugins.footer();
        MARTIAN.Plugins.mobileMenuHeight();
        MARTIAN.Plugins.teamProfileResize();
    };

    /**
     * Functions those need to run when the document is scrolling
     */
    MARTIAN.onScroll = function () {
        MARTIAN.Plugins.header();
    };


    /**
     * All of Functions for Martian Project.
     * @type {Object}
     */
    MARTIAN.Plugins = {

        /**
         * Control Header
         */
        header: function () {
            var $headerHeight = Selectors.$header.outerHeight(),
                $scrollTop = $window.scrollTop(),
                $faker = $('#masthead-faker'),
                $sticky = Selectors.$body.hasClass('sticky-header');

            if ($sticky && $scrollTop >= $headerHeight) {
                Selectors.$header.addClass('fixed');
                $faker.css('height', $headerHeight + 'px');
            } else {
                Selectors.$header.removeClass('fixed');
                $faker.css('height', '');
            }
        },

        /**
         * Control Footer
         */
        footer: function () {
            var $footerHeight = Selectors.$footer.outerHeight(),
                $mask = $('#site-footer-mask'),
                $sticky = Selectors.$body.hasClass('footer-not-fixed');

            if ($sticky === false && $window.outerWidth() > 768) {
                $mask.css('height', $footerHeight + 'px');
            } else {
                $mask.css('height', '');
            }
        },

        /**
         * Menu Toggler
         */
        menuToggle: function () {
            Selectors.$menuToggle.on('click', function () {
                $(this).toggleClass('active');
                Selectors.$menuContainer.toggleClass('visible');
            });
        },

        /**
         * Mobile Menu
         */
        mobileMenu: function () {
            var $items = $('.menu-item-has-children', Selectors.$menuContainer);

            $items.each(function () {
                var $this = $(this),
                    $anchor = $('> a', $this);

                $anchor.on('click', function (e) {
                    var $this = $(this),
                        style = $this.next().attr('style');
                    e.preventDefault();
                    $this.parent().parent().find('.menu-item-has-children').removeClass('sub-menu-open');
                    $this.parent().parent().find('.menu-item-has-children > .sub-menu').slideUp();
                    if (!style || style === 'display: none;') {
                        $this.closest('.menu-item-has-children').toggleClass('sub-menu-open');
                        $this.next().slideToggle();
                    }

                });
            });
        },

        /**
         * Mobile Menu Height Set
         */
        mobileMenuHeight: function () {

            var $innerHeight = $window.innerHeight(),
                $outerWidth = $window.outerWidth(),
                $headerHeight = Selectors.$header.outerHeight(),
                $adminBar = $('#wpadminbar').outerHeight(),
                height = $innerHeight - $headerHeight;

            if (Selectors.$body.hasClass('admin-bar')) {
                height = height - $adminBar;
            }

            if ($outerWidth <= 768) {
                Selectors.$menuContainer.css({
                    'max-height': height + "px",
                    'overflow': 'auto'
                });
            } else {
                Selectors.$menuContainer.css({
                    'max-height': '',
                    'overflow': ''
                });
                $('.menu-item-has-children', Selectors.$menuContainer).removeClass('sub-menu-open');
                $('.menu-item-has-children > .sub-menu', Selectors.$menuContainer).css({
                    'display': ''
                });
            }
        },

        /**
         * The Carousel function with Swiper and SwiperRunner.
         */
        slider: function () {

            //Main Slider
            Selectors.$slider.each(function () {
                var $this = $(this),
                    $container = $('.swiper-container', $this)[0];
                var swiper = new SwiperRunner($container);

            });
        },

        /**
         * The tow way carousel function with Swiper and SwiperRunner.
         */
        sliderWithNav: function () {

            Selectors.$sliderWT.each(function () {
                var $this = $(this),
                    $main = $('.swiper-container', $this)[0],
                    $thumb = $('.swiper-container', $this)[1];
                var swiper = new SwiperRunner($main);
                swiper.setNav($thumb);
            });

        },

        /**
         * Universal Carousel
         */
        carouselUniversal: function () {
            Selectors.$carouselUV.each(function () {
                new SwiperRunner($(this));
            });
        },

        /**
         * Universal Carousel With Thumbnail
         */
        carouselUniversalWithThumb: function () {
            Selectors.$carouselUVT.each(function () {
                var $this = $(this),
                    $main = $('.swiper-container', $this)[0],
                    $nav = $('.swiper-container', $this)[1];

                var swiper = new SwiperRunner($main);
                swiper.setNav($nav);
            });
        },

        /**
         * Skill Progress bars
         * @param $el jQuery selector object
         */
        skillBars: function ($el) {
            $el.each(function () {

                var $this = $(this),
                    val = $this.data('progress');

                if ($.fn.appear) {
                    $this.appear(function () {
                        $this.animate({width: val + "%"}, {duration: 1000});
                    }, {accX: 0, accY: -30});
                } else {
                    $this.animate({width: val + "%"}, {duration: 1000});
                }

            });
        },

        /**
         * Ajax Post Like
         * @param el css selector
         */
        ajaxPostLike: function (el) {
            $(el).each(function () {
                var $this = $(this),
                    id = $this.data('id');

                $this.one('click', function (e) {

                    $.post(
                        martian_ajax.ajax_url,
                        {
                            action: 'martian_ajax_like',
                            id: id
                        },
                        function (res) {
                            $this.find('.likeCount').html(res);
                            $this.addClass('active');
                        }
                    );

                    e.preventDefault();
                });
            });
        },

        /**
         * Light Gallery
         * @param el css selector
         * @param opt options for light gallery plugin
         */
        lightGallery: function (el, opt) {

            $(el).each(function () {
                var $this = $(this),
                    type = $this.data('type');

                if (type) {
                    $.getScript("https://cdn.jsdelivr.net/g/lg-video")
                        .done(function () {
                            $this.lightGallery(opt);
                        })
                        .fail(function () {
                            console.error('lg-video.js load failed');
                        });
                } else if (type === 'vimeo') {
                    $.getScript("https://f.vimeocdn.com/js/froogaloop2.min.js")
                        .done(function () {
                            $this.lightGallery(opt);
                        })
                        .fail(function () {
                            console.error('Vimeo froogaloop2.min.js load failed');
                        });
                } else if (type === 'all') {
                    $.getScript("https://f.vimeocdn.com/js/froogaloop2.min.js")
                        .done(function () {

                        })
                        .fail(function () {
                            console.error('Vimeo froogaloop2.min.js load failed');
                        });
                    $.when(
                        $.getScript("https://cdn.jsdelivr.net/g/lg-video"),
                        $.getScript("https://f.vimeocdn.com/js/froogaloop2.min.js"),
                        $.Deferred(function (deferred) {
                            $(deferred.resolve);
                        })
                    ).done(function () {
                        $this.lightGallery(opt);
                    });
                } else {
                    $this.lightGallery(opt);
                }
            })
        },

        /**
         * Justified Gallery
         */
        justifiedGallery: function () {

            Selectors.$jfGallery.each(function () {
                $(this).justifiedGallery({
                    rowHeight: 250,
                    lastRow: 'nojustify'
                });
            })
        },

        /**
         * Statics Counter
         * @param $el jQuery selector object
         * @link https://codepen.io/hi-im-si/pen/uhxFn
         */
        staticsCounter: function ($el) {

            // Countable Function
            function doCount($el) {
                var countTo = $el.data('counter'),
                    duration = $el.data('duration');

                $el.text('0');
                $({countNum: $el.text()}).animate(
                    {
                        countNum: countTo
                    },
                    {
                        duration: duration ? duration : 3000,
                        easing: 'linear',
                        step: function () {
                            $el.text(Math.floor(this.countNum));
                        },
                        complete: function () {
                            $el.text(this.countNum);
                        }
                    }
                );
            }

            // Run while appear
            $el.each(function () {
                var $this = $(this);

                if ($.fn.appear) {

                    $this.appear(function () {
                        doCount($this);
                    }, {accX: 0, accY: -100});

                } else {
                    doCount($this);
                }

            });
        },

        /**
         * Team Profile Resize
         */
        teamProfileResize: function () {
            Selectors.$teamProfiles.each(function () {
                $('.martian-member-profile', $(this)).each(function () {
                    var $this = $(this),
                        parentWidth = $this.parent().innerWidth(),
                        width = parentWidth - 30;

                    $this.css({
                        width: width + 'px',
                        height: width + 'px'
                    })
                });
            })
        },

        /**
         * Countdown Timer
         */
        countdownTimer: function () {
            Selectors.$countdownTimer.each(function () {
                var $this = $(this),
                    date = $this.data('date');

                $this.countdown(date, function (event) {

                    // Countdown format
                    var format = '' +
                        '<div class="item"><div class="content"><span>%-d</span><span>day%!d</span></div></div>' +
                        '<div class="item"><div class="content"><span>%H</span><span>Hour%!H</span></div></div>' +
                        '<div class="item"><div class="content"><span>%M</span><span>Minute%!M</span></div></div>' +
                        '<div class="item"><div class="content"><span>%S</span><span>Second%!S</span></div></div>';

                    // Print to the selected element
                    $(this).html(event.strftime(format));
                });
            });
        },

        /**
         * Ajax Form Manager
         */
        ajaxFormManager: function () {
            Selectors.$ajaxForm.each(function () {
                var $this = $(this);
                $('.form-result', $this).css('display', 'none');

                $this.submit(function () {

                    $('button[type="submit"]', $this).addClass('clicked');

                    // Create a object and assign all fields name and value.
                    var values = {};

                    $('[name]', $this).each(function () {
                        var $this = $(this);
                        values[$this.attr('name')] = $this.val();
                    });

                    // Make Request
                    $.ajax({
                        url: $this.attr('action'),
                        type: 'POST',
                        data: values,
                        success: function success(data) {
                            if (data.error === true) {
                                $('.form-result', $this).addClass('alert-warning').removeClass('alert-success alert-danger').css('display', 'block');
                            } else {
                                $('.form-result', $this).addClass('alert-success').removeClass('alert-warning alert-danger').css('display', 'block');
                            }
                            $('.form-result > .content', $this).html(data.message);
                            $('button[type="submit"]', $this).removeClass('clicked');
                        },
                        error: function error() {
                            $('.form-result', $this).addClass('alert-danger').removeClass('alert-warning alert-success').css('display', 'block');
                            $('.form-result > .content', $this).html('Sorry, an error occurred.');
                            $('button[type="submit"]', $this).removeClass('clicked');
                        }
                    });

                    return false;
                });
            });
        },

        /**
         * Handle video & audio players
         */
        plyr: function () {
            plyr.setup(Selectors.fullscreenVideo);
        },

        /**
         * Isotope Masonry Gallery
         */
        isotopeMasonryGallery: function () {
            Selectors.$isotopeMasonryGallery.each(function () {
                $(this).isotope({
                    itemSelector: '.item'
                })
            });
        },

        /**
         * Isotope Filterable Gallery
         */
        isotopeFilterableGallery: function () {
            Selectors.$isotopeFilterableGallery.each(function () {
                var $this = $(this),
                    $gallery = $('.martian-filterable-container', $this),
                    $filters = $('.martian-filter-buttons', $this);

                var $container = $gallery.isotope({
                    itemSelector: '.item'
                });

                $filters.on('click', 'button', function () {
                    var filterValue = $(this).attr('data-filter');
                    $container.isotope({filter: filterValue});
                });

                // Filter Button Activation
                $filters.each(function () {
                    var $this = $(this);
                    $this.on('click', 'button', function (e) {
                        $('.active', $this).removeClass('active');
                        $(this).addClass('active');
                        e.preventDefault();
                    });
                });
            });
        },

        /**
         * Before After
         */
        beforeAfter: function () {
            Selectors.$beforeAfter.each(function () {
                $(this).beforeAfter();
            })
        },

        /**
         * Play The Slider Audio
         */
        handleSliderAudio: function () {
            Selectors.$carouselAudio.each(function () {
                var $this = $(this),
                    $audio = $('> audio', $this),
                    $audioEl = $('> audio', $this)[0],
                    $btn = $('> .playBtn', $this);

                $btn.on('click', function () {
                    $('i', $btn).toggleClass('fa-volume-up fa-volume-off');

                    if ($audioEl.paused) {
                        $audioEl.play();

                    } else {
                        $audioEl.pause();
                    }
                });

                $audio.on('ended', function () {
                    $('i', $btn).toggleClass('fa-volume-up fa-volume-off');
                });

            });
        }

    };


    /**
     * All Helper functions
     */
    MARTIAN.Helpers = {

        /**
         * Set Background from to parent dive
         * @param options {object} including selector and css value
         */
        setBackground: function (options) {

            $(options.el).each(function () {
                var $this = $(this),
                    $img = $('> img.makeCover', $this).eq(0),
                    imgUrl = $img.attr('src');

                var css = {
                    backgroundImage: 'url(' + imgUrl + ')',
                    imgVisible: null,
                    css: null
                };

                $.extend(css, options.css);

                $this.css(css);
                if (options.imgVisible !== true) {
                    $img.hide();
                }
            });
        },

        /**
         * Make Fullscreen an element
         * @param $el jQuery selector
         */
        makeFullscreen: function ($el) {
            var vh = $window.innerHeight(),
                hw = $window.innerWidth();

            $el.css({
                width: hw,
                height: vh
            });
        },

        /**
         * Browser Detect
         * @link https://stackoverflow.com/a/34840631
         */
        browserDetect: function () {
            var $html = Selectors.$html;

            // Opera 8.0+ (UA detection to detect Blink/v8-powered Opera)
            var isOpera = !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
            if (isOpera) {
                $html.addClass('martian-browser-opera');
            }
            // Firefox 1.0+
            var isFirefox = typeof InstallTrigger !== 'undefined';

            if (isFirefox) {
                $html.addClass('martian-browser-firefox');
            }
            // Safari 3.0+
            var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) {
                return p.toString() === "[object SafariRemoteNotification]";
            })(!window['safari'] || safari.pushNotification);

            if (isSafari) {
                $html.addClass('martian-browser-safari');
            }
            // Internet Explorer 6-11
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            if (isIE) {
                $html.addClass('martian-browser-ie');
            }

            // Edge 20+
            var isEdge = !isIE && !!window.StyleMedia;
            if (isEdge) {
                $html.addClass('martian-browser-edge');
            }

            // Chrome 1+
            var isChrome = !!window.chrome && !!window.chrome.webstore;
            if (isChrome) {
                $html.addClass('martian-browser-chrome');
            }

            // Blink engine detection
            // var isBlink = (isChrome || isOpera) && !!window.CSS;
            // if (isBlink) {
            //     $html.addClass('martian-browser-blink');
            // }
        }
    };


    MARTIAN.Init = function () {
        $document.ready(MARTIAN.onReady);
        $window.on('load', MARTIAN.onLoad);
        $window.on('resize', MARTIAN.onResize);
        $window.on('scroll', MARTIAN.onScroll);
    };

    // Let's kick ass ;)
    MARTIAN.Init();


})(jQuery);