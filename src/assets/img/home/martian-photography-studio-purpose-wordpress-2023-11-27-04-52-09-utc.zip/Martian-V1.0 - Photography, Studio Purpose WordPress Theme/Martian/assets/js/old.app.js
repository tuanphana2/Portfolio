var DECENTTHEMES = DECENTTHEMES || {};

(function ($) {

    // Beautiful functions stack by Mominul Islam <mominul@infinitystate.com>
    // Font-End Developer @DECENTTHEMES
    // USE STRICT
    "use strict";

    DECENTTHEMES.initialize = {

        init: function () {
            DECENTTHEMES.initialize.defaults();
            // DECENTTHEMES.initialize.revSlider();
            // DECENTTHEMES.initialize.swiper();
            // DECENTTHEMES.initialize.waterwheelCarousel();
            DECENTTHEMES.initialize.sectionCustomize();
            // DECENTTHEMES.initialize.count_timer();
            // DECENTTHEMES.initialize.skills();
            // DECENTTHEMES.initialize.countup();
        },

        /*-----------------------------------------------
         # Defaults
         ---------------------------------------------*/

        defaults: function () {
            if (document.getElementById('grid')) {
                new AnimOnScroll(document.getElementById('grid'), {
                    minDuration: 0.4,
                    maxDuration: 0.7,
                    viewportFactor: 0.2
                });
            }

            $(window).on('load', function () {
                $("#pre-loader").fadeOut("slow");

            });

            // $('ul.sf-menu').superfish({
            //     delay: 500,
            //     animation: {opacity: 'show', height: 'show'},
            //     speed: 'normal',
            //     autoArrows: false,
            //     minWidth: 12,
            //     maxWidth: 27,
            //     extraWidth: 1,
            //     cssArrows: false
            // });


            // $("#mt-justified-gallery").justifiedGallery({
            // 	rowHeight : 300,
            // 	margins: 0,
            // 	captions: false

            // });

            // $.sidebarMenu($('.sidebar-menu'))
            // Wow Js
            // new WOW().init();


            /* Video Plyer Init */

            // $('audio, video').each(function() {
            // 	var opt = {};

            // 	if ($(this).data('autoplay')) {
            // 		opt.autoplay = $(this).data('autoplay');
            // 	}

            // 	if ($(this).data('controls')) {
            // 		opt.controls = $(this).data('controls');
            // 	}

            // 	plyr.setup(this, opt);
            // });


            // $('.grid, .gallery-grid-items').lightGallery({
            // 	selector: '.grid-item, .grid-items',
            // 	thumbnail: true
            // });

            // $('#mt-justified-gallery').lightGallery({
            // 	selector: 'a'
            // });

            // Before After init
            // $('.ba-slider').beforeAfter();

            // $.sidebarMenu($('.sidebar-menu'));

            $('[data-mt-toggle]').each(function () {
                var $this = $(this),
                    $class = $this.data('mt-toggle');

                $this.on('click', function (e) {
                    e.preventDefault();
                    $this.toggleClass('active');
                    $('body').toggleClass($class);
                })
            });
        },

        /*-----------------------------------------------
         # Revolution Kenburns Effect
         ---------------------------------------------*/

        revSlider: function () {
            /* initialize the slider based on the Slider's ID attribute */
            $('#rev_slider_1').show().revolution({

                /* options are 'auto', 'fullwidth' or 'fullscreen' */
                sliderLayout: 'fullscreen',
                stopLoop: 'off',
                delay: 4000,

                dottedOverlay: 'off',
                spinner: "off",
                disableProgressBar: "on",
                fallbacks: "off",
                navigation: {
                    onHoverStop: 'off',
                    arrows: {
                        enable: true,
                        style: 'gyges',
                        hide_onleave: true
                    },

                }
            });

            $('#rev_slider_2').show().revolution({
                sliderLayout: 'fullscreen',
                sliderType: "hero",
                delay: 9000,
                spinner: "off",
                responsiveLevels: [1240, 1024, 778, 480],
                visibilityLevels: [1240, 1024, 778, 480],
                gridwidth: [1400, 1024, 778, 480],
                gridheight: [800, 700, 600, 500],
                lazyType: "none",
            });

            $('#rev_youtube').show().revolution({
                sliderLayout: 'fullscreen',
                sliderType: "hero",
                dottedOverlay: "none",
                spinner: "off",

            });

            $('#rev_vimeo').show().revolution({
                sliderLayout: 'fullscreen',
                sliderType: "hero",
                dottedOverlay: "none",
                spinner: "off",

            });
        },

        /*-----------------------------------------------
         # Swiper Slider
         ---------------------------------------------*/

        swiper: function () {
            $('[data-carousel="swiper"]').each(function () {

                var $this = $(this);
                var $container = $this.find('[data-swiper="container"]');
                var $asControl = $this.find('[data-swiper="ascontrol"]');

                var conf = function (element) {
                    var obj = {
                        slidesPerView: element.data('items'),
                        centeredSlides: element.data('center'),
                        loop: element.data('loop'),
                        initialSlide: element.data('initial'),
                        effect: element.data('effect'),
                        spaceBetween: element.data('space'),
                        autoplay: element.data('autoplay'),
                        direction: element.data('direction'),
                        paginationType: element.data('pagination-type'),
                        paginationClickable: true,
                        breakpoints: element.data('breakpoints'),
                        speed: element.data('speed'),
                        slideToClickedSlide: element.data('click-to-slide'),
                        mousewheelControl: element.data('mousewheel'),
                        loopedSlides: element.data('looped'),
                        fade: {
                            crossFade: element.data('crossfade')
                        }
                    };
                    return obj;
                }

                var $primaryConf = conf($container);
                $primaryConf.prevButton = $this.find('[data-swiper="prev"]');
                $primaryConf.nextButton = $this.find('[data-swiper="next"]');
                $primaryConf.pagination = $this.find('[data-swiper="pagination"]');

                var $ctrlConf = conf($asControl);

                function animateSwiper(selector, slider) {
                    var makeAnimated = function animated() {
                        selector.find('.swiper-slide-active [data-animate]').each(function () {
                            var anim = $(this).data('animate');
                            var delay = $(this).data('delay');
                            var duration = $(this).data('duration');

                            $(this).addClass(anim + ' animated')
                                .css({
                                    webkitAnimationDelay: delay,
                                    animationDelay: delay,
                                    webkitAnimationDuration: duration,
                                    animationDuration: duration
                                })
                                .one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
                                    $(this).removeClass(anim + ' animated');
                                });
                        });
                    };
                    makeAnimated();
                    slider.on('SlideChangeStart', function () {
                        selector.find('[data-animate]').each(function () {
                            var anim = $(this).data('animate');
                            $(this).removeClass(anim + ' animated');
                        });
                    });
                    slider.on('SlideChangeEnd', makeAnimated);
                };

                if ($container.length) {
                    var $swiper = new Swiper($container, $primaryConf);
                    animateSwiper($this, $swiper);
                    // play
                    $('.controls-wrapper', $container).on('click', '.swiper-play', function () {
                        $swiper.params.autoplay = 4000;
                        $swiper.startAutoplay();
                        $('.swiper-play, .swiper-pause').toggleClass('hidden');
                    });
                    // Pause
                    $('.controls-wrapper', $container).on('click', '.swiper-pause', function () {
                        $swiper.stopAutoplay();
                        $('.swiper-play, .swiper-pause').toggleClass('hidden');
                    });

                    if ($asControl.length) {
                        var $control = new Swiper($asControl, $ctrlConf);
                        $swiper.params.control = $control;
                        $control.params.control = $swiper;
                    }

                } else {
                    console.log('Swiper container is not defined!');
                }
                ;
            });
        },

        /*-----------------------------------------------
         # WaterWheel Carousel
         ---------------------------------------------*/

        waterwheelCarousel: function () {

            var control = $('#flow-gallery').waterwheelCarousel({
                horizonOffset: 3,
                speed: 400,
                separation: 200,
                separationMultiplier: 0.8,
                sizeMultiplier: 0.8,
                opacityMultiplier: 1,
                animationEasing: 'jswing',
                autoPlay: 5000,
            });

            $('#flow-prev').bind('click', function () {
                control.prev();
                return false
            });

            $('#flow-next').bind('click', function () {
                control.next();
                return false;
            });

            var bcontrol = $('#brand-carousel').waterwheelCarousel({
                autoPlay: "4000",
                horizonOffset: 3,
                speed: 400,
                separation: 200,
                separationMultiplier: 0.7,
                sizeMultiplier: 0.8,
                opacityMultiplier: 1,
                animationEasing: 'jswing',
                flankingItems: 5,
            });

            $('#brand-prev').bind('click', function () {
                bcontrol.prev();
                return false
            });

            $('#brand-next').bind('click', function () {
                bcontrol.next();
                return false;
            });

        },

        /*-----------------------------------------------
         # Isotope
         ---------------------------------------------*/

        isotopeInit: function () {
            $('[data-area="isotope"]').each(function () {

                var container = $(this).find('[data-isotope="container"]');
                var filters = $(this).find('[data-filters]');

                var portfolio = container.isotope({
                    itemSelector: '.dt-gallery-item',
                    masonry: {
                        columnWidth: 1
                    }
                });

                setTimeout(function () {
                    container.isotope('layout');
                }, 500);


                filters.on('click', '.dt-btn', function () {
                    var filterValue = $(this).attr('data-filter');
                    portfolio.isotope({filter: filterValue});
                });

            });

            // Masonary
            $('.grid').isotope({
                // options
                itemSelector: '.grid-item',
                masonry: {
                    columnWidth: 0
                }
            });

            // Full Screen Board Masonary
            $('.board').isotope({
                // options
                itemSelector: '.board-item',
                masonry: {
                    columnWidth: 0
                }
            });

            // Blog Masonary
            $('.blog-grid').isotope({
                // options
                itemSelector: '.img-grid',
                masonry: {
                    columnWidth: 1
                }
            });

            // Protfolio Masonary
            $('.masonary-grid4').isotope({
                // options
                itemSelector: '.masonary-item4',
                masonry: {
                    columnWidth: 0
                }
            });

            $('.masonary-grid').isotope({
                // options
                itemSelector: '.masonary-item',
                masonry: {
                    columnWidth: 0
                }
            });
        },

        /*-----------------------------------------------
         # Background Image
         ---------------------------------------------*/

        sectionCustomize: function () {
            $('[data-bg-color]').each(function () {

                var value = $(this).data('bg-color');
                $(this).css({
                    backgroundColor: value,
                });
            });

            $('[data-bg-image]').each(function () {

                var img = $(this).data('bg-image');

                $(this).css({
                    backgroundImage: 'url(' + img + ')',
                });
            });
        },

        /*-----------------------------------------------
         # Count Timer
         ---------------------------------------------*/

        count_timer: function () {
            $('#clock').countdown('2016/12/30', function (event) {
                var $this = $(this).html(event.strftime(''
                    + '<span><p>%d</p> days</span>  '
                    + '<span><p>%H</p> hours</span>  '
                    + '<span><p>%M</p> mins</span>  '
                    + '<span><p>%S</p> seconds</span> '));
            });
        },

        /*-----------------------------------------------
         # Skills
         ---------------------------------------------*/

        skills: function () {
            $(function () {
                $('progress').each(function () {
                    var max = $(this).val();

                    $(this).appear(function () {
                        $(this).val(0).animate({value: max}, {duration: 2000});
                    }, {accX: 0, accY: 0})
                });
            });
        },
        /*-----------------------------------------------
         # Count Up
         ---------------------------------------------*/

        countup: function () {
            var options = {
                useEasing: true,
                useGrouping: true,
                separator: ',',
                decimal: '.',
                prefix: '',
                suffix: ''
            };

            var counteEl = $('[data-counter]');

            if (counteEl) {
                counteEl.each(function () {
                    var val = $(this).data('counter');

                    var countup = new CountUp(this, 0, val, 0, 2.5, options);
                    $(this).appear(function () {
                        countup.start();
                    }, {accX: 0, accY: 0})
                });
            }
        },
    };


    DECENTTHEMES.documentOnReady = {
        init: function () {
            DECENTTHEMES.initialize.init();
            DECENTTHEMES.initialize.sectionCustomize();
        },
    };

    DECENTTHEMES.documentOnload = {
        init: function () {
            // DECENTTHEMES.initialize.isotopeInit();
        },
    };

    DECENTTHEMES.documentOnResize = {
        init: function () {
        },
    };

    DECENTTHEMES.documentOnScroll = {
        init: function () {
            /* Parallax Spped */

            // $('.parallax').jarallax({
            // 	speed: 0.2
            // });

            /* Sticky Menu */

            if ($(this).scrollTop() > 200) {
                $('.dt-header').addClass("navbar-small")
            }
            else {
                $('.dt-header').removeClass("navbar-small")
            }
        },
    };

    // Initialize Functions
    $(document).ready(DECENTTHEMES.documentOnReady.init);
    $(window).on('load', DECENTTHEMES.documentOnload.init);
    $(window).on('resize', DECENTTHEMES.documentOnResize.init);
    $(window).on('scroll', DECENTTHEMES.documentOnScroll.init);

    /*-----------------------------------------------
     # Mobile Menu
     ---------------------------------------------*/

    $.sidebarMenu = function (menu) {
        var animationSpeed = 300;

        $(menu).on('click', 'li a', function (e) {
            var $this = $(this);
            var checkElement = $this.next();

            if (checkElement.is('.treeview-menu') && checkElement.is(':visible')) {
                checkElement.slideUp(animationSpeed, function () {
                    checkElement.removeClass('menu-open');
                });
                checkElement.parent("li").removeClass("active");
            }


            else if ((checkElement.is('.treeview-menu')) && (!checkElement.is(':visible'))) {

                var parent = $this.parents('ul').first();

                var ul = parent.find('ul:visible').slideUp(animationSpeed);

                ul.removeClass('menu-open');

                var parent_li = $this.parent("li");


                checkElement.slideDown(animationSpeed, function () {

                    checkElement.addClass('menu-open');
                    parent.find('li.active').removeClass('active');
                    parent_li.addClass('active');
                });
            }

            if (checkElement.is('.treeview-menu')) {
                e.preventDefault();
            }
        });
    }

})(jQuery);


/**
 * Functions for Martian
 */
(function ($) {

    "use strict";

    // Dom Caches
    var $header = $('#masthead'),
        $menuContainer = $('#martian-main-menu'),
        $menuToggle = $('#nav-toggle');


    // Set Background Image
    function setSlideBackground() {
        $('.swiper-slide.makeBackground').each(function () {
            var $this = $(this),
                $image = $('> img.slide-image', $this),
                $Url = $image.attr('src');

            $this.css({
                backgroundImage: 'url("' + $Url + '")',
                backgroundRepeat: 'no-repeat',
                backgroundSize: 'cover',
                backgroundPosition: 'center center'
            });
            $image.hide();
        });
    }

    // Audio Play/Pause
    function audioControl(swiper) {

        $('.swiper-slide-audio').each(function () {
            var $this = $(this),
                $audio = $('> audio', $this)[0],
                $btn = $('> .playBtn', $this);

            swiper.on('slideChangeStart', function () {
                $audio.pause();
                $('i', $btn).removeClass('fa-volume-up').addClass('fa-volume-off');
            });

            $btn.on('click', function () {
                $('i', $btn).toggleClass('fa-volume-up fa-volume-off');

                if ($audio.paused) {
                    $audio.play();

                } else {
                    $audio.pause();
                }
            });
        })
    }

    // Menu Toggle
    function menuToggle() {
        $menuToggle.on('click', function () {
            $(this).toggleClass('active');
            $menuContainer.toggleClass('visible');
        });
    }

    // Mobile Menu Implement
    function fixMobileMenu() {
        var $items = $('.menu-item-has-children', $menuContainer);

        $items.each(function () {
            var $this = $(this),
                $anchor = $('> a', $this);

            $anchor.on('click', function (e) {
                var $this = $(this),
                    style = $this.next().attr('style');
                e.preventDefault();
                $this.parent().parent().find('.menu-item-has-children').removeClass('sub-menu-open');
                $this.parent().parent().find('.menu-item-has-children > .sub-menu').slideUp();
                if (!style || style === 'display: none;') {
                    $this.closest('.menu-item-has-children').toggleClass('sub-menu-open');
                    $this.next().slideToggle();
                }

            });
        });

        function menuHeight() {
            var $innerHeight = $(window).innerHeight(),
                $outerWidth = $(window).outerWidth(),
                $headerHeight = $header.outerHeight();

            if ($outerWidth < 768) {
                $menuContainer.css({
                    'max-height': ($innerHeight - $headerHeight) + "px",
                    'overflow': 'auto'
                });
            } else {
                $menuContainer.css({
                    'max-height': '',
                    'overflow': ''
                });
                $('.menu-item-has-children > .sub-menu', $menuContainer).css({
                    'display': ''
                });
            }
        }

        menuHeight();

        $(window).on('resize', function () {
            menuHeight();
        });
    }

    // Run When Document Is Ready
    $(document).ready(function () {

        //Main Slider
        $('.martian-slider.default').each(function () {
            var $this = $(this),
                $container = $('.swiper-container', $this)[0];

            var swiper = new swiperRunner($container);
            audioControl(swiper.main);

        });

        // With Thumbnails
        $('.martian-slider.with-thumbnails').each(function () {
            var $this = $(this),
                $main = $('.swiper-container', $this)[0],
                $thumb = $('.swiper-container', $this)[1];

            var swiper = new swiperRunner($main);
            swiper.setNav($thumb);
            audioControl(swiper.main);
        });

        // Set Background Image
        setSlideBackground();

        // Menu Toggle
        menuToggle();

        // Fix Mobile Menu
        fixMobileMenu();

    });


})(jQuery);