/**
 * File customize-preview.js.
 *
 * Instantly live-update customizer settings in the preview for improved user experience.
 */

(function ($) {

    var transparent,
        $body = $('body'),
        $siteHeader = $('#martian-page-header'),
        $error404 = $('#error-404-page'),
        $logo = $('#logo'),
        $siteFooter = $('#site-footer');

    // Site Logo
    wp.customize('custom_logo', function (value) {
        value.bind(function (ID) {

            wp.media.attachment(ID).fetch().then(function () {
                var $url = wp.media.attachment(ID).get('url');

                if ($url) {
                    $('.logo-normal', $logo).attr('src', $url);
                }

            });

        });
    });
    wp.customize('custom_logo_contrast', function (value) {
        value.bind(function (ID) {

            wp.media.attachment(ID).fetch().then(function () {
                var $url = wp.media.attachment(ID).get('url');

                if ($url) {
                    $('.logo-contrast', $logo).attr('src', $url);
                }

            });

        });
    });

    // Box Border Layout
    wp.customize('martian_general_box_border', function (value) {
        value.bind(function (value) {
            if (value) {
                $body.addClass('box-border-layout');
            } else {
                $body.removeClass('box-border-layout');
            }
        });
    });

    // Transparent Header
    wp.customize('martian_header_transparent', function (value) {
        value.bind(function (value) {
            if (value) {
                $body.addClass('transparent-header');
                transparent = true;
            } else if (!value) {
                $body.removeClass('transparent-header');
                transparent = false;
            }
        });
    });

    // Closed Header
    wp.customize('martian_header_closed', function (value) {
        value.bind(function (value) {
            if (value) {
                $body.addClass('closed-header');
            } else if (!value) {
                $body.removeClass('closed-header');
            }
        });
    });

    // Sticky Header
    wp.customize('martian_header_sticky', function (value) {
        value.bind(function (value) {
            if (value) {
                $body.addClass('sticky-header');
            } else if (!value) {
                $body.removeClass('sticky-header');
            }
        });
    });

    // Page Header
    wp.customize('martian_page_header_enable', function (value) {
        value.bind(function (value) {
            if (value === true) {
                $siteHeader.show();
                if (transparent) {
                    $body.addClass('transparent-header');
                }
            } else {
                $siteHeader.hide();
                if (transparent) {
                    $body.removeClass('transparent-header');
                }
            }

        });
    });

    // Page header title
    wp.customize('martian_page_header_title', function (value) {
        value.bind(function (to) {
            $('.page-title', $siteHeader).text(to);
        });
    });

    // Page header description
    wp.customize('martian_page_header_desc', function (value) {
        value.bind(function (to) {
            $('.page-description', $siteHeader).text(to);
        });
    });

    // Page header image
    wp.customize('martian_page_header_image', function (value) {
        value.bind(function (value) {
            if (value) {
                $siteHeader.css('background-image', 'url(' + value + ')');
            }
        });
    });

    // Footer Not Fixed
    wp.customize('martian_footer_fixed', function (value) {
        value.bind(function (value) {
            if (!value) {
                $body.addClass('footer-not-fixed');
            } else {
                $body.removeClass('footer-not-fixed');
            }
        });
    });

    // Footer Copyright text
    wp.customize('martian_footer_copyright', function (value) {
        value.bind(function (to) {
            $('.site-info > p', $siteFooter).html(to);
        });
    });

    // 404 Error
    wp.customize('martian_404_code', function (value) {
        value.bind(function (to) {
            $('.martian_404_code', $error404).text(to);
        });
    });
    wp.customize('martian_404_message', function (value) {
        value.bind(function (to) {
            $('.martian_404_message', $error404).text(to);
        });
    });
    wp.customize('martian_404_image', function (value) {
        value.bind(function (value) {
            if (value) {
                $error404.css('background-image', 'url(' + value + ')');
            }
        });
    });

})(jQuery);
