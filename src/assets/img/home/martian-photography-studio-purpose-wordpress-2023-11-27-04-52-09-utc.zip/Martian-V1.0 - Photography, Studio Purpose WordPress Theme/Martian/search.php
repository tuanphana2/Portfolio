<?php
/**
 * The template for displaying search results pages
 *
 * @link       https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.0
 */
$sidebar = get_theme_mod( 'martian_sidebar_blog', 'none' );

$mainColumn = 'col-md-12';
if ( $sidebar !== 'none' ) {
	$mainColumn = 'col-md-9 pull-' . $sidebar;
}
get_header(); ?>

	<div class="wrap inner-pages-container">
		<div class="container">
			<div class="row">
				<div id="primary" class="<?php echo esc_attr( $mainColumn ); ?> content-area">
					<main id="main" class="site-main martian-posts-archives">

						<?php
						if ( have_posts() ) :

							while ( have_posts() ) : the_post();
								get_template_part( 'template-parts/post/content', 'excerpt' );
							endwhile;

							the_posts_pagination( array(
								'prev_text'          => '<i class="fa fa-arrow-left"></i><span class="screen-reader-text">' . __( 'Previous page', 'martian' ) . '</span>',
								'next_text'          => '<span class="screen-reader-text">' . __( 'Next page', 'martian' ) . '</span><i
								class="fa fa-arrow-right"></i>',
								'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'martian' ) . ' </span>',
							) );

						else :

							get_template_part( 'template-parts/post/content', 'none' );

						endif; ?>

					</main><!-- #main -->
				</div><!-- #primary -->

				<?php if ( $sidebar !== 'none' ) : ?>
					<div class="col-md-3">
						<?php get_sidebar(); ?>
					</div><!-- /.col-md-3 -->
				<?php endif; ?>
			</div><!-- /.row -->
		</div><!-- /.container -->
	</div><!-- .wrap -->

<?php get_footer();
