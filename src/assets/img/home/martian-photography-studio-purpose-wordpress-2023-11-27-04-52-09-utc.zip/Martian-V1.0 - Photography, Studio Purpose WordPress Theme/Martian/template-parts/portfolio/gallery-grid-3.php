<?php
/**
 * Template part for displaying gallery
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.2
 */

// Meta Info
$meta = get_post_meta( get_the_ID(), '_martian_portfolio_details', true );

if ( ! empty( $meta['gallery_images'] ) ) :
	wp_enqueue_script( 'wow' );
	wp_enqueue_style( 'animate-css' );
	wp_enqueue_style( 'lightgallery' );
	wp_enqueue_script( 'lightgallery' );
	?>
	<div class="martian-grid-gallery row martian-lightGallery">
		<?php
		foreach ( $meta['gallery_images'] as $item ) {

			if ( ! empty( $item['main'] ) ) {
				echo '<a class="item col-sm-6 col-md-4 wow fadeInUp" href="' . wp_get_attachment_image_url( $item['main'], 'full' ) . '"><div class="martian-gallery-img-thumbnail">';
				echo wp_get_attachment_image( $item['main'], 'martian-album-thumb' );
				echo '<i class="fa fa-eye"></i>';
				echo '</div></a>';
			}
		}
		?>
	</div><!-- /.martian-masonry-gallery -->
<?php else :
	echo '<h3>' . esc_html__( 'No Photos Found!', 'martian' ) . '</h3>';
endif;