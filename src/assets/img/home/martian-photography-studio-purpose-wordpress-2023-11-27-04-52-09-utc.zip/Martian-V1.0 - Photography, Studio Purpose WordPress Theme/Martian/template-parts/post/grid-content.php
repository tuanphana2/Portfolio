<?php
/**
 * Template part for displaying posts
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.2
 */

$classes = array(
	'post-grid'
);

$cover = get_post_meta( get_the_ID(), '_martian_post_cover', true );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	<?php if ( ! empty( $cover['image'] ) ) : ?>
		<div class="post-featured-content">
			<a href="<?php the_permalink(); ?>">
				<?php echo wp_get_attachment_image( $cover['image'], 'full' ); ?>
			</a>
		</div><!-- .post-featured-content -->
	<?php elseif ( has_post_thumbnail() ): ?>
		<div class="post-featured-content">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'medium' ); ?>
			</a>
		</div><!-- .post-featured-content -->
	<?php endif; ?>

	<header class="entry-header">

		<?php
		if ( is_front_page() && is_home() ) {
			the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
		} else {
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		}
		?>
	</header><!-- .entry-header -->

	<div class="entry-summary">
		<?php martian_the_excerpt( 110 ); ?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<div class="author vcard">
			<i class="fa fa-user"></i>
			<?php the_author_posts_link(); ?>
		</div><!-- /.author -->
		<div class="date">
			<i class="fa fa-clock-o"></i>
			<?php echo martian_time_link_full(); ?>
		</div><!-- /.date -->
		<div class="readmore">
			<a href="<?php the_permalink(); ?>">
				<i class="fa fa-share"></i>
				<?php echo esc_html__( 'Read More', 'martian' ); ?>
			</a>
		</div><!-- /.date -->
	</footer><!-- /.entry-footer -->


</article><!-- #post-## -->
