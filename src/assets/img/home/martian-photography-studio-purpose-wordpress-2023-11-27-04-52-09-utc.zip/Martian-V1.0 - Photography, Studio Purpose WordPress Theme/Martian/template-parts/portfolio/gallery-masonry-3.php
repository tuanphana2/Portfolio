<?php
/**
 * Template part for displaying gallery
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.2
 */

// Meta Info
$meta = get_post_meta( get_the_ID(), '_martian_portfolio_details', true );

if ( ! empty( $meta['gallery_images'] ) ) :
	wp_enqueue_script( 'isotope' );
	wp_enqueue_style( 'lightgallery' );
	wp_enqueue_script( 'lightgallery' );
	?>
	<div class="martian-masonry-gallery column-3 mt-isotope-masonry martian-lightGallery">
		<?php
		foreach ( $meta['gallery_images'] as $item ) {

			if ( ! empty( $item['main'] ) ) {
				echo '<a class="item wow fadeInUp" href="' . wp_get_attachment_image_url( $item['main'], 'full' ) . '"><div class="martian-gallery-img-thumbnail">';
				if ( $item['preview'] ) {
					echo wp_get_attachment_image( $item['preview'], 'full' );
				} else {
					echo wp_get_attachment_image( $item['main'], 'medium' );
				}

				echo '<i class="fa fa-eye"></i>';
				echo '</div></a>';
			}
		}
		?>
	</div><!-- /.martian-masonry-gallery -->
<?php else :
	echo '<h3>' . esc_html__( 'No Photos Found!', 'martian' ) . '</h3>';
endif;