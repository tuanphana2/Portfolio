<?php
/**
 * Template part for displaying gallery
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.2
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php
		// Meta Info
		$meta = get_post_meta( get_the_ID(), '_martian_portfolio_details', true );

		if ( ! empty( $meta['gallery_images'] ) ) :
			wp_enqueue_style( 'before-after' );
			wp_enqueue_script( 'before-after' );

			$images = array_values( $meta['gallery_images'] );

			if ( ! empty( $images[0]['main'] ) && ! empty( $images[1]['main'] ) ) :
				?>
				<div class="portfolio-details-image">
					<div class="ba-slider martian-before-after">
						<?php echo wp_get_attachment_image( $images[0]['main'], 'full' ); ?>
						<div class="after-image resize">
							<?php echo wp_get_attachment_image( $images[1]['main'], 'full' ); ?>
						</div>
						<i class="fa fa-arrows handle"></i>
					</div><!-- /.martian-before-after -->
				</div><!-- /.portfolio-details-image -->
				<?php
			endif;
		endif;
		?>
		<div class="post-title-meta">
			<?php
			the_title( '<h1 class="entry-title">', '</h1>' );
			?>
			<div class="entry-meta">
				<span class="ajaxLike" data-id="<?php the_ID(); ?>">
					<i class="fa fa-heart-o"></i>
					<span class="likeCount"><?php echo esc_html( martian_get_loveCount( get_the_ID(), false ) ); ?></span>
				</span>
				<span>
					<i class="fa fa-eye"></i>
					<span><?php echo esc_html( martian_get_postViews( get_the_ID() ) ); ?></span>
				</span>
			</div><!-- /.entry-meta -->
		</div>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php the_content(); ?>

		<div class="row portfolio-details-involve">
			<div class="col-md-4">
				<?php if ( ! empty( $meta['additional_info'] ) ) {
					echo '<ul class="project-info">';
					foreach ( $meta['additional_info'] as $item ) {
						echo '<li>';
						echo '<span class="name">' . esc_html( $item['name'] ) . '</span>';
						echo '<span class="desc">' . esc_html( $item['desc'] ) . '</span>';
						echo '</li>';
					}
					echo '</ul>';
				}
				?>
			</div><!-- /.col-md-4 -->
			<div class="col-md-8">
				<?php
				if ( ! empty( $meta['team_member'] ) ) :
					wp_enqueue_style( 'swiper' );
					wp_enqueue_script( 'swiper-runner' );
					$unique     = uniqid( 'swpr-contrl-' );
					$swiperConf = array(
						'loop'          => true,
						'slidesPerView' => 2,
						'nextButton'    => '#' . $unique . 'next',
						'prevButton'    => '#' . $unique . 'prev',
						'breakpoints'   => array(
							768  => array(
								'slidesPerView' => 1
							),
							5000 => array(
								'slidesPerView' => 2
							),
						)
					);

					?>

					<div class="project-involvement-carousel">
						<?php if ( ! empty( $meta['team_title'] ) ) : ?>
							<h3 class="title"><?php echo esc_html( $meta['team_title'] ); ?></h3>
						<?php endif; ?>
						<div class="swiper-container martian-carousel-UV"
							 data-swiper-config='<?php echo json_encode( $swiperConf ); ?>'>
							<div class="swiper-wrapper">

								<?php
								foreach ( $meta['team_member'] as $post ) :
									$id = $post['id'];
									$meta = get_post_meta( $id, '_martian_member_details', true );
									?>
									<div class="swiper-slide">
										<div class="martian-member-profile setBackground">
											<?php
											if ( has_post_thumbnail( $id ) ) {
												echo wp_get_attachment_image(
													get_post_thumbnail_id( $id ),
													'full',
													null,
													array( 'class' => 'profileImage makeCover' )
												);
											} else {
												echo '<img src="' . MARTIAN_ESS_DIR_URL . 'assets/img/profile-mask.jpg' . '" alt="" class="profileImage makeCover">';
											}
											?>

											<div class="profileInfo">
												<div class="profileInfoInner">
													<?php
													// Job
													if ( ! empty( $meta['title'] ) ) {
														echo '<div class="job">' . esc_html( $meta['title'] ) . '</div>';
													}

													// Name
													if ( ! empty( $meta['name'] ) ) {
														echo '<h3 class="title">' . esc_html( $meta['name'] ) . '</h3>';
													} else {
														echo '<h3 class="title">' . get_the_title( $id ) . '</h3>';
													}

													// Social Profile
													if ( ! empty( $meta['social_profiles'] ) ) {
														echo '<ul class="social-profiles list-inline">';
														foreach ( $meta['social_profiles'] as $profile ) {
															echo '<li><a href="' . esc_url( $profile['link'] ) . '" title="' . esc_attr( $profile['name'] ) . '">';
															echo '<i class="' . esc_attr( $profile['icon'] ) . '"></i>';
															echo '</a></li>';
														}
														echo '</ul>';
													}
													?>
												</div><!-- /.profileInfoInner -->
											</div><!-- /.profileInfo -->
										</div><!-- /.martian-member-profile -->
									</div><!-- /.swiper-slide -->
								<?php endforeach; ?>
							</div><!-- /.swiper-wrapper -->
						</div><!-- /.swiper-container -->

						<!-- Controls -->
						<div id="<?php echo esc_attr( $unique . 'prev' ); ?>"
							 class="swiper-button-prev"></div>
						<div id="<?php echo esc_attr( $unique . 'next' ); ?>"
							 class="swiper-button-next"></div>
					</div><!-- /.project-involvement-carousel -->
				<?php endif; ?>
			</div><!-- /.col-md-8 -->
		</div><!-- /.row -->

		<!-- Additional Info-->

		<?php
		// Share Links
		if (function_exists('martian_share_buttons')) {
			echo martian_share_buttons();
		}

		wp_link_pages( array(
			'before'      => '<div class="page-links">' . __( 'Pages:', 'martian' ),
			'after'       => '</div>',
			'link_before' => '<span class="page-number">',
			'link_after'  => '</span>',
		) );
		?>
	</div><!-- .entry-content -->

</article><!-- #post-## -->
