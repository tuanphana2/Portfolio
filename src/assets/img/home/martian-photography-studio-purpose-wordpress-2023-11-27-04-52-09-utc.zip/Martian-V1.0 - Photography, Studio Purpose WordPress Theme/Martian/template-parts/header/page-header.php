<?php
/**
 * Header for all inner pages
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0.0
 * @version    1.0.0
 */
$banner_display       = get_theme_mod( 'martian_page_header_enable', true );
$banner_default_img   = get_theme_file_uri( '/assets/img/placeholder.jpg' );
$banner_img_opt       = get_theme_mod( 'martian_page_header_image' );
$banner_image         = ( ! empty( $banner_img_opt ) ) ? $banner_img_opt : $banner_default_img;
$banner_default_title = esc_html__( 'Blog', 'martian' );
$banner_default_desc  = esc_html__( 'Read Recent News From HQ', 'martian' );
$banner_title         = get_theme_mod( 'martian_page_header_title', $banner_default_title );
$banner_desc          = get_theme_mod( 'martian_page_header_desc', $banner_default_desc );

if ( is_singular() ) {

	global $post;

	$banner_title = get_the_title( $post->ID );
	$post_opt     = get_post_meta( $post->ID, '_martian_page_options', true );

	if ( is_array( $post_opt ) ) {

		if ( isset( $post_opt['page_header_global'] ) && $post_opt['page_header_global'] == false ) {

			if ( ! empty( $post_opt['custom_title'] ) ) {
				$banner_title = $post_opt['custom_title'];
			}

			if ( ! empty( $post_opt['custom_description'] ) ) {
				$banner_desc = $post_opt['custom_description'];
			}

			$banner_display = isset( $post_opt['page_header'] ) ? $post_opt['page_header'] : $banner_display;

			if ( ! empty( $post_opt['header_image'] ) ) {
				$banner_image = wp_get_attachment_url( $post_opt['header_image'] );
			} elseif ( has_post_thumbnail( $post->ID ) ) {
				$banner_image = get_the_post_thumbnail_url( $post->ID, 'full' );
			}

		}

	}

} elseif ( is_archive() ) {

	$banner_title = get_the_archive_title();
	$banner_desc  = get_the_archive_description();

} elseif ( is_search() ) {

	if ( have_posts() ) {
		$banner_title = sprintf( esc_html__( 'Search Results for: %s', 'martian' ), get_search_query() );
		$banner_desc  = esc_html__( 'Here is all results for your interest.', 'martian' );
	} else {
		$banner_title = esc_html__( 'Nothing Found', 'martian' );
		$banner_desc  = esc_html__( 'We didn\'t have any content for you.', 'martian' );
	}

} elseif ( is_404() ) {
	$banner_display = false;
}

if ( $banner_display == false ) {
	return;
}
?>
<div id="martian-page-header" class="martian-page-header setBackground">
	<img src="<?php echo esc_url( $banner_image ); ?>" alt="" class="makeCover">
	<div class="container page-header-content">
		<div class="page-title-container">
			<span></span>
			<h2 class="page-title"><?php echo wp_kses_post( $banner_title ); ?></h2>
			<span></span>
		</div>
		<?php if ( $banner_desc ) : ?>
			<div class="page-description"><?php echo wp_kses_post( $banner_desc ); ?></div>
		<?php endif; ?>
	</div><!-- /.container -->
</div><!-- /.martian-page-header -->
