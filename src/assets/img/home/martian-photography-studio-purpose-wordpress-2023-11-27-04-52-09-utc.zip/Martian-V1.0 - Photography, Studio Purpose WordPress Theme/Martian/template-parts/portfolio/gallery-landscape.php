<?php
/**
 * Template part for displaying gallery
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.2
 */

// Meta Info
$meta         = get_post_meta( get_the_ID(), '_martian_portfolio_details', true );
$itemsCount   = 0;
$galleryCount = esc_html__( 'No Photos', 'martian' );

if ( ! empty( $meta['gallery_images'] ) ) {
	// Load Scripts
	wp_enqueue_style( 'swiper' );
	wp_enqueue_script( 'swiper-runner' );

	// Modify Variables
	$images       = count( $meta['gallery_images'] );
	$itemsCount   = $images;
	$galleryCount = $images . ' ' . esc_html__( 'Photos', 'martian' );
}

//Main Config
$mainConf = array(
	'loop'         => true,
	'loopedSlides' => $itemsCount,
	'autoHeight'   => true,
	'effect'       => 'fade',
	'fade'         => array(
		'crossFade' => true
	),
	'autoplay'     => 4000,
);
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php
	if ( ! empty( $meta['gallery_images'] ) ) :
		?>
		<div class="portfolio-gallery-carousel portrait martian-carousel-UV swiper-container"
			 data-swiper-config='<?php echo json_encode( $mainConf ); ?>'>
			<div class="swiper-wrapper">
				<?php
				foreach ( $meta['gallery_images'] as $image ) {
					if ( ! empty( $image['main'] ) ) {
						echo '<div class="swiper-slide">';
						echo wp_get_attachment_image( $image['main'], 'full' );
						echo '</div>';

					}
				}
				?>
			</div><!-- /.swiper-wrapper -->

			<!-- Controls -->
			<div class="swiper-button-prev clear-arrow"></div>
			<div class="swiper-button-next clear-arrow"></div>

			<!-- Playing Controls -->
			<div class="swiper-playing-control">
				<span class="swiper-play"><i class="fa fa-play"></i></span>
				<span class="swiper-pause"><i class="fa fa-pause"></i></span>
			</div>

		</div><!-- /.swiper-container -->

		<div class="gallery-meta-and-sharer">
			<div class="entry-meta pull-left">
						<span class="ajaxLike" data-id="<?php the_ID(); ?>">
							<i class="fa fa-heart-o"></i>
							<span class="likeCount"><?php echo esc_html( martian_get_loveCount( get_the_ID(), false ) ); ?></span>
						</span>
				<span>
							<i class="fa fa-eye"></i>
							<span><?php echo esc_html( martian_get_postViews( get_the_ID() ) ); ?></span>
						</span>
			</div><!-- /.entry-meta -->
			<div class="pull-right">
				<?php
				// Share Links
				if (function_exists('martian_share_buttons')) {
					echo martian_share_buttons();
				}
				?>
			</div>
		</div><!-- /.gallery-meta-and-sharer -->
	<?php endif; ?>

	<div class="entry-content">
		<?php
		the_content();

		// Additional Info
		if ( ! empty( $meta['additional_info'] ) ) {
			echo '<ul class="project-info">';
			foreach ( $meta['additional_info'] as $item ) {
				echo '<li>';
				echo '<span class="name">' . esc_html( $item['name'] ) . '</span>';
				echo '<span class="desc">' . esc_html( $item['desc'] ) . '</span>';
				echo '</li>';
			}
			echo '</ul>';
		}

		wp_link_pages( array(
			'before'      => '<div class="page-links">' . __( 'Pages:', 'martian' ),
			'after'       => '</div>',
			'link_before' => '<span class="page-number">',
			'link_after'  => '</span>',
		) );
		?>
	</div><!-- .entry-content -->

</article><!-- #post-## -->
