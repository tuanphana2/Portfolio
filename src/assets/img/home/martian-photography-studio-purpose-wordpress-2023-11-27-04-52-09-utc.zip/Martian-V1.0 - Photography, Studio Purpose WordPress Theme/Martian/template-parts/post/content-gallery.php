<?php
/**
 * Template part for displaying gallery posts
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.2
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php

	$meta       = get_post_meta( get_the_ID(), '_martian_post_format_options', true );
	$getGallery = get_post_gallery( get_the_ID(), false );

	if ( ! empty( $meta['images'] ) ) {
		$ids = explode( ',', $meta['images'] );
		$ids = array_slice( $ids, 0, 3 );

		echo '<div class="post-featured-content"><div class="entry-gallery">';
		foreach ( $ids as $id ) {
			echo '<div class="item setBackground">';
			echo wp_get_attachment_image( $id, 'martian-featured-image', null, array( 'class' => 'makeCover' ) );
			echo '</div>';
		}
		echo '</div></div><!-- .post-featured-content -->';
	} elseif ( ! is_single() && ! empty( $getGallery['ids'] ) ) {
		$ids = explode( ',', $getGallery['ids'] );
		$ids = array_slice( $ids, 0, 3 );

		echo '<div class="post-featured-content"><div class="entry-gallery">';
		foreach ( $ids as $id ) {
			echo '<div class="item setBackground">';
			echo wp_get_attachment_image( $id, 'martian-featured-image', null, array( 'class' => 'makeCover' ) );
			echo '</div>';
		}
		echo '</div></div><!-- .post-featured-content -->';
	} elseif ( has_post_thumbnail() ) {
		echo '<div class="post-featured-content">';
		echo '<a href="' . get_permalink() . '">';
		the_post_thumbnail( 'martian-featured-image' );
		echo '</a>';
		echo '</div><!-- .post-featured-content -->';
	}
	?>
	<header class="entry-header">

		<?php
		echo '<div class="posted-on">';
		echo martian_time_link();
		echo '</div>';
		echo '<div class="post-title-meta">';
		if ( is_single() ) {
			the_title( '<h1 class="entry-title">', '</h1>' );
		} elseif ( is_front_page() && is_home() ) {
			the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
		} else {
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		}

		martian_entry_meta();
		echo '</div>';
		// if (function_exists('martian_share_buttons') &&  is_single()) {
		// 	echo martian_share_buttons();
		// }
		?>
	</header><!-- .entry-header -->

	<div class="entry-content">

		<?php

		if ( ! is_single() ) {
			martian_the_excerpt();

			echo '<div class="readmore-btn">';
			echo '<a class="btn btn-martian btn-blk" href="' . esc_url( get_permalink() ) . '">' . esc_html__( 'Read More', 'martian' ) . '</a>';
			echo '</div>';

		} else {
			the_content();

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="pages">' . __( 'Pages:', 'martian' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span class="page-number">',
				'link_after'  => '</span>',
			) );
		}

		?>

	</div><!-- .entry-content -->

	<?php if ( is_single() ) : ?>
		<?php martian_entry_footer(); ?>
	<?php endif; ?>

</article><!-- #post-## -->
