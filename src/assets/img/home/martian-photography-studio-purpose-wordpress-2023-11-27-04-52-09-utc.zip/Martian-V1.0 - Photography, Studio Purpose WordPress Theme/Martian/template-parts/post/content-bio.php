<?php
/**
 * Displaying author bio box
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0.0
 */
$job         = get_the_author_meta( 'job' );
$description = get_the_author_meta( 'description' );

if ( 'post' !== get_post_type() || empty( $description ) ) {
	return;
}
?>

<div class="martian-author-bio">
	<div class="author-photo">
		<?php echo get_avatar( get_the_author_meta( 'email' ), '100' ); ?>
	</div><!-- /.author-photo -->

	<div class="content">
		<h4 class="name">
			<?php
			echo '<span>' . esc_html__( 'About Author: ', 'martian' ) . '</span>';
			echo get_the_author();
			?>
		</h4>
		<?php


		if ( ! empty( $job ) ) {
			echo '<h5 class="job">' . esc_html( $job ) . '</h5>';
		}
		if ( ! empty( $description ) ) {
			echo '<div class="description">';
			echo wpautop( $description );
			echo '</div>';
		}
		?>
	</div><!-- /.content -->
</div><!-- /.martian-author-bio -->
