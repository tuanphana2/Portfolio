<?php
/**
 * Template part for displaying gallery
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.2
 */

// Meta Info
$meta = get_post_meta( get_the_ID(), '_martian_portfolio_details', true );

$type = '';
if ( ! empty( $meta['gallery_type'] ) ) {
	$type = $meta['gallery_type'];
}

get_template_part( 'template-parts/portfolio/gallery', $type );
