<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link       https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.0
 */

get_header(); ?>

	<div class="wrap">
		<div id="primary" class="content-area">
			<main id="main" class="site-main">

				<section id="error-404-page" class="error-404 not-found setBackground">
					<?php
					$defaultImage = get_theme_file_uri( '/assets/img/placeholder.jpg' );
					$image        = get_theme_mod( 'martian_404_image', $defaultImage );
					?>
					<img src="<?php echo esc_url( $image ); ?>" alt="" class="makeCover">

					<div class="error-404-content">
						<div class="martian_404_code">
							<?php echo esc_html( get_theme_mod( 'martian_404_code', '404' ) ); ?>
						</div><!-- /.martian_404_code -->
						<div class="martian_404_message">
							<?php echo esc_html( get_theme_mod( 'martian_404_message', 'Error' ) ); ?>
						</div><!-- /.martian_404_message -->

						<div class="martian_404_actions">
							<?php
							if ( get_theme_mod( 'martian_404_home', true ) ) {
								echo '<a href="' . esc_url( home_url( '/' ) ) . '" class="btn btn-alt btn-martian">' . esc_html__( 'Home', 'martian' ) . '</a>';
							}
							if ( get_theme_mod( 'martian_404_back', true ) ) {
								echo '<a href="#0" onclick="history.go(-1)" class="btn btn-alt btn-martian">' . esc_html__( 'Previous Page', 'martian' ) . '</a>';
							}
							?>
						</div><!-- /.martian_404_actions -->
					</div><!-- /.error-404-content -->
				</section><!-- .error-404 -->
			</main><!-- #main -->
		</div><!-- #primary -->
	</div><!-- .wrap -->

<?php get_footer();
