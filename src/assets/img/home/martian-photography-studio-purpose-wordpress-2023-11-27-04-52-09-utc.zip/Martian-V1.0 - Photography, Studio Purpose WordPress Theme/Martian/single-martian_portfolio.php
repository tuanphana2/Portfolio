<?php
/**
 * The template for displaying all single posts
 *
 * @link       https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.0
 */

$meta           = get_post_meta( get_the_ID(), '_martian_portfolio_details', true );
$containerClass = 'container';
$mainColumn     = 'col-md-9 sidebar-enabled';
$sidebar        = true;
$inLayoutType   = array(
	'masonry-3',
	'masonry-4',
	'masonry-5',
	'grid-2',
	'grid-3',
	'grid-4',
	'grid-6',
	'justified'
);

// Check if fluid
if ( ! empty( $meta['gallery_type'] ) ) {
	if ( in_array( $meta['gallery_type'], $inLayoutType ) && ! empty( $meta['wide_layout'] ) ) {
		$containerClass = 'container-fluid';
	}
}

// Check if gutter less
if ( ! empty( $meta['gutter_less'] ) ) {
	$containerClass .= ' gutter-less';
}

// Check if sidebar
if ( empty( $meta['sidebar_enabled'] ) ) {
	$mainColumn = 'col-md-12 sidebar-disabled';
	$sidebar    = false;
}

get_header(); ?>

	<div class="wrap inner-pages-container">
		<div class="<?php echo esc_attr( $containerClass ); ?>">
			<div class="singlePostNavigation">
				<?php
				$prevPostTitle = esc_html__( 'Previous', 'martian' );
				$prevMarkup    = '<i class="fa fa-long-arrow-left" aria-hidden="true"></i><span>' . $prevPostTitle . '</span>';
				$nextPostTitle = esc_html__( 'Next', 'martian' );
				$nextMarkup    = '<span>' . $nextPostTitle . '</span><i class="fa fa-long-arrow-right" aria-hidden="true"></i>';
				$homeURL       = get_post_type_archive_link( 'martian_portfolio' );

				if ( ! empty( get_theme_mod( 'martian_portfolio_archive_link' ) ) ) {
					$homeURL = get_theme_mod( 'martian_portfolio_archive_link' );
				}

				// Prev
				echo '<div class="prev">';
				previous_post_link( '%link', $prevMarkup );
				echo '</div>';

				// Home
				echo '<div class="home">';
				echo '<a href="' . esc_url( $homeURL ) . '" title="' . esc_attr__( 'Back to archive', 'martian' ) . '"><i class="fa fa-th" aria-hidden="true"></i></a>';
				echo '</div>';

				// Next
				echo '<div class="next">';
				next_post_link( '%link', $nextMarkup );
				echo '</div>';

				?>
			</div><!-- /.singlePostPagination -->
			<div class="row">
				<div id="primary" class="content-area <?php echo esc_attr( $mainColumn ); ?>">
					<main id="main" class="site-main" role="main">

						<?php
						/* Start the Loop */
						while ( have_posts() ) : the_post();

							get_template_part( 'template-parts/portfolio/content', get_post_format() );
							?>
							<div class="martian-related-posts">
								<div class="martian-section-heading">
									<div class="content">
										<div class="sub-title"><?php esc_html_e( 'You may like this', 'martian' ); ?></div>
										<h2 class="title"><?php esc_html_e( 'Related Works', 'martian' ); ?></h2>
									</div>
								</div>
								<?php martian_related_posts( array(
									'post_type' => 'martian_portfolio',
									'taxonomy'  => 'martian_portfolio_cat',
									'columnSize' => 3,
									'limit' => 3
								) ); ?>
							</div>
						<?php endwhile; // End of the loop.
						?>
					</main><!-- #main -->
				</div><!-- #primary -->
				<?php if ( $sidebar ) : ?>
					<div class="col-md-3">
						<?php get_sidebar(); ?>
					</div><!-- /.col-md-3 -->
				<?php endif; ?>
			</div><!-- /.row -->
		</div><!-- /.container -->
	</div><!-- .wrap -->

<?php get_footer();
