<?php
/**
 * Additional features to allow styling of the templates
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 *
 * @return array
 */
function martian_body_classes( $classes ) {
	// Add class of group-blog to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Add class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Add class if we're viewing the Customizer for easier styling of theme options.
	if ( is_customize_preview() ) {
		$classes[] = 'martian-customizer';
	}

	// Add class on front page.
	if ( is_front_page() && 'posts' !== get_option( 'show_on_front' ) ) {
		$classes[] = 'martian-front-page';
	}

	// Add a class if there is a custom header.
	if ( has_header_image() ) {
		$classes[] = 'has-header-image';
	}

	// Add class if sidebar is used.
	if ( is_active_sidebar( 'sidebar-1' ) && ! is_page() ) {
		$classes[] = 'has-sidebar';
	}

	// Add class for one or two column page layouts.
	if ( is_page() || is_archive() ) {
		if ( 'one-column' === get_theme_mod( 'page_layout' ) ) {
			$classes[] = 'page-one-column';
		} else {
			$classes[] = 'page-two-column';
		}
	}

	if ( is_404() ) {
		$classes[] = 'no-footer-mask';
	}

	// Get the colorscheme or the default if there isn't one.
	$colors    = martian_sanitize_colorscheme( get_theme_mod( 'colorscheme', 'light' ) );
	$classes[] = 'colors-' . $colors;

	// Add box-border-layout if disabled
	if ( get_theme_mod( 'martian_general_box_border', false ) ) {
		$classes[] = 'box-border-layout';
	}

	// Check page header enabled and has transparent header
	$transparent = get_theme_mod( 'martian_header_transparent', false );
	$pageHeader  = get_theme_mod( 'martian_page_header_enable', true );

	if ( is_singular() ) {
		global $post;
		$postSettings = get_post_meta( $post->ID, '_martian_page_options', true );

		// Transparent Header
		if ( ! martian_is_frontpage() ) {
			if ( ! empty( $postSettings ) && $postSettings['page_header_global'] == false ) {
				$pageHeader = $postSettings['page_header'];

				if ( ! empty( $postSettings['transparent_header'] ) ) {
					$pageHeader = true;
				}
			}
		}

		// Footer fix
		if ( ! empty( $postSettings['footer_mask_fix'] ) ) {
			$classes[] = 'no-footer-mask';
		}

		// Box layout
		if ( ! empty( $postSettings['box_layout'] ) ) {
			$classes[] = 'box-border-layout';
		}
	}

	// Add transparent-header class if enabled
	if ( $transparent && $pageHeader ) {
		$classes[] = 'transparent-header';
	}

	// Add closed-header if enabled
	if ( get_theme_mod( 'martian_header_closed', false ) ) {
		$classes[] = 'closed-header';
	}

	// Add sticky-header if enabled
	if ( get_theme_mod( 'martian_header_sticky', true ) ) {
		$classes[] = 'sticky-header';
	}

	// Add footer-not-fixed if disabled
	if ( get_theme_mod( 'martian_footer_fixed', true ) == false ) {
		$classes[] = 'footer-not-fixed';
	}

	return $classes;
}

add_filter( 'body_class', 'martian_body_classes' );


/**
 * Get Liked Count
 *
 * @param int         $post_ID The post ID
 * @param bool|string $text    the 'views' text
 *
 * @return string
 */
function martian_get_loveCount( $post_ID, $text = true ) {
	$count_key = 'liked';
	$count     = get_post_meta( $post_ID, $count_key, true );
	$loved     = ' ';
	if ( $text === true ) {
		$loved .= esc_attr__( 'Liked', 'martian' );
	} elseif ( ! empty( $text ) ) {
		$loved .= $text;
	}

	if ( ! empty( $count ) ) {
		return $count . $loved;
	} else {
		return 0 . $loved;
	}
}

/**
 * Set Ajax Post Like
 */
function martian_ajax_post_like() {
	$post_ID   = filter_input( INPUT_POST, 'id', FILTER_VALIDATE_INT );
	$count_key = 'liked';
	$count     = get_post_meta( $post_ID, $count_key, true );

	if ( ! empty( $count ) ) {
		$count ++;
		update_post_meta( $post_ID, $count_key, $count );

	} else {
		add_post_meta( $post_ID, $count_key, '1' );
		$count = 1;
	}

	echo $count;

	wp_die();
}

add_action( 'wp_ajax_martian_ajax_like', 'martian_ajax_post_like' );
add_action( 'wp_ajax_nopriv_martian_ajax_like', 'martian_ajax_post_like' );

/**
 * Get Post Views Count
 *
 * @param int    $post_ID The post ID
 * @param string $text    the 'views' text
 *
 * @return string
 */
function martian_get_postViews( $post_ID, $text = '' ) {
	$count_key = 'views';
	$count     = get_post_meta( $post_ID, $count_key, true );
	$text      = ( empty( $text ) ) ? esc_attr__( 'Views', 'martian' ) : $text;

	if ( ! empty( $count ) ) {
		return $count . ' ' . $text;
	} else {
		return 0 . ' ' . $text;
	}
}

/**
 * Set the post views
 */
function martian_set_postViews() {

	if ( function_exists( 'the_views' ) ) {
		return;
	}

	global $post;

	if ( is_singular() ) {
		$count_key = 'views';
		$count     = get_post_meta( $post->ID, $count_key, true );

		if ( ! empty( $count ) ) {
			$count ++;
			update_post_meta( $post->ID, $count_key, $count );
		} else {
			add_post_meta( $post->ID, $count_key, '1' );
		}
	}
}

add_action( 'wp_head', 'martian_set_postViews' );

/**
 * Checks to see if we're on the homepage or not.
 *
 * @return bool
 */
function martian_is_frontpage() {
	return ( is_front_page() && ! is_home() );
}

/**
 * Modify archive link count
 *
 * @param $links
 *
 * @return mixed
 */
function martian_modify_archive_count( $links ) {
	$links = str_replace( '</a>&nbsp;(', '</a> <span class="count">', $links );
	$links = str_replace( ')', '</span>', $links );

	return $links;
}

add_filter( 'get_archives_link', 'martian_modify_archive_count' );

/**
 * Add SVG definitions to the footer.
 */
function martian_include_svg_masks() {
	// Define SVG sprite file.
	$svg_icons = get_parent_theme_file_path( '/assets/img/masks.svg' );

	// If it exists, include it.
	if ( file_exists( $svg_icons ) ) {
		require_once( $svg_icons );
	}
}

add_action( 'wp_footer', 'martian_include_svg_masks', 9999 );

/**
 * Modify Category link count
 *
 * @param $links
 *
 * @return mixed
 */
function martian_modify_category_count( $links ) {
	$links = str_replace( '</a> (', '</a> <span class="count">(', $links );
	$links = str_replace( ')', ')</span>', $links );

	return $links;
}

//add_filter( 'wp_list_categories', 'martian_modify_category_count' );

/**
 * Get the excerpt with new limit
 *
 * @param  integer $charlength limit of the character
 *
 * @return string             the new excerpt
 */
function martian_the_excerpt( $charlength = 400 ) {
	$excerpt = get_the_excerpt();
	$charlength ++;

	if ( mb_strlen( $excerpt ) > $charlength ) {

		$subex   = mb_substr( $excerpt, 0, $charlength - 5 );
		$exwords = explode( ' ', $subex );
		$excut   = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );

		if ( $excut < 0 ) {
			echo mb_substr( $subex, 0, $excut );
		} else {
			echo $subex;
		}

		echo '...';

	} else {
		echo $excerpt;
	}
}

/**
 * Related Post Render
 *
 * @param array $args
 */
function martian_related_posts( $args = array() ) {

	$defaults = array(
		'post_type'  => 'post',
		'taxonomy'   => 'category',
		'limit'      => 4,
		'columnSize' => 4
	);
	$args     = wp_parse_args( $args, $defaults );

	global $post;

	$terms = array();
	if ( is_object( $post ) ) {
		$terms = wp_get_post_terms( $post->ID, $args['taxonomy'] );
	} else {
		$terms = wp_get_post_terms( $post['id'], $args['taxonomy'] );
	}

	if ( $terms ) {

		$taxonomy_query = array();

		if ( count( $terms ) > 1 ) {
			$taxonomy_query['relation'] = 'OR';
		}

		foreach ( $terms as $term ) {

			$taxonomy_query[] = array(
				'taxonomy' => $args['taxonomy'],
				'field'    => 'slug',
				'terms'    => $term->slug,
			);
		}
		$query_args = array(
			'post_type'           => $args['post_type'],
			'post__not_in'        => array( $post->ID ),
			'posts_per_page'      => $args['limit'],
			'ignore_sticky_posts' => true,
			'tax_query'           => $taxonomy_query
		);

		$the_query = new WP_Query( $query_args );

		if ( $the_query->have_posts() ) :

			echo '<ul id="related-posts-with-' . $post->ID . '" class="related-posts column-size-' . esc_attr( $args['columnSize'] ) . '">';

			while ( $the_query->have_posts() ) :
				$the_query->the_post();
				echo '<li class="related-item-thumb">';
				echo '<a href="' . get_permalink() . '" rel="bookmark">';
				echo '<span class="thumb">';
				if ( has_post_thumbnail() ) {
					the_post_thumbnail( 'martian-related-thumb' );
				} else {
					echo '<img src="' . get_parent_theme_file_uri( '/assets/img/related-thumb-mask.jpg' ) . '" alt="">';
				}
				echo '</span>';

				echo '<span class="caption"><span>';
				echo '<span class="title">' . get_the_title() . '</span>';
				echo '<span class="date">' . get_the_date() . '</span>';
				echo '</span></span>';

				echo '</a>';
				echo '</li>';

			endwhile;
			echo '</ul>';
		else :
			echo '<div class="related-posts">';
			echo '<p class="related-not-found">' . esc_html__( 'No related posts found.', 'martian' ) . '</p>';
			echo "</div>";
		endif;
	}

	wp_reset_postdata();
}

/**
 * Detect visual composer
 *
 * @return boolean
 */
function martian_is_vc_content() {
	global $post;
	$matches        = array();
	$preg_match_ret = preg_match( '/\[.*vc_row.*\]/s', $post->post_content, $matches );
	if ( $preg_match_ret !== 0 && $preg_match_ret !== false ) {
		return true;
	}

	return false;
}


/**
 * Martian Logo
 *
 * @return string markup of html
 */
function martian_logo() {
	$logoNormal      = get_theme_mod( 'custom_logo' );
	$logoContrast    = get_theme_mod( 'custom_logo_contrast' );
	$logoNormalUrl   = get_theme_file_uri( '/assets/img/logo-black.png' );
	$logoContrastUrl = get_theme_file_uri( '/assets/img/logo.png' );

	echo '<a id="logo" href="' . esc_url( home_url( '/' ) ) . '">';

	if ( ! empty( $logoNormal ) ) {
		echo wp_get_attachment_image( $logoNormal, 'full', '', array( 'class' => 'logo-normal' ) );
	} else {
		echo '<img src="' . esc_url( $logoNormalUrl ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="logo-normal">';
	}

	if ( ! empty( $logoContrast ) ) {
		echo wp_get_attachment_image( $logoContrast, 'full', '', array( 'class' => 'logo-contrast' ) );
	} else {
		echo '<img src="' . esc_url( $logoContrastUrl ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="logo-contrast">';
	}

	echo '</a>';
}
