<?php
/**
 * Martian: Customizer
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 */

if ( class_exists( 'WP_Customize_Control' ) ) {
	class Martian_Customize_Heading_Control extends WP_Customize_Control {
		/**
		 * Render the control's content.
		 *
		 * @since 3.4.0
		 */
		public function render_content() {
			echo '<div id="' . esc_attr( $this->id ) . '" class="martian-options-header">';
			echo esc_html( $this->label );
			echo '</div>';
		}
	}
}

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function martian_customize_register( $wp_customize ) {
	$wp_customize->selective_refresh->get_partial( 'custom_logo' )->fallback_refresh = false;
	$wp_customize->get_setting( 'blogname' )->transport                              = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport                       = 'postMessage';

	/**
	 * Custom Logo Transparent
	 */
	$wp_customize->add_setting( 'custom_logo_contrast', array(
		'transport'         => 'postMessage',
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'custom_logo_contrast', array(
		'label'         => esc_html__( 'Logo (Contrast)', 'martian' ),
		'section'       => 'title_tagline',
		'priority'      => 9,
		'height'        => 50,
		'width'         => 150,
		'flex_height'   => true,
		'flex_width'    => true,
		'button_labels' => array(
			'select'       => esc_html__( 'Select logo', 'martian' ),
			'change'       => esc_html__( 'Change logo', 'martian' ),
			'remove'       => esc_html__( 'Remove', 'martian' ),
			'default'      => esc_html__( 'Default', 'martian' ),
			'placeholder'  => esc_html__( 'No logo selected', 'martian' ),
			'frame_title'  => esc_html__( 'Select logo', 'martian' ),
			'frame_button' => esc_html__( 'Choose logo', 'martian' ),
		),
	) ) );

	/**
	 * Custom colors.
	 */
	$wp_customize->add_setting( 'colorscheme', array(
		'default'           => 'light',
		'transport'         => 'postMessage',
		'sanitize_callback' => 'martian_sanitize_colorscheme',
	) );

	$wp_customize->add_setting( 'colorscheme_hue', array(
		'default'           => 250,
		'transport'         => 'postMessage',
		'sanitize_callback' => 'absint', // The hue is stored as a positive integer.
	) );

	$wp_customize->add_control( 'colorscheme', array(
		'type'     => 'radio',
		'label'    => __( 'Color Scheme', 'martian' ),
		'choices'  => array(
			'light'  => __( 'Light', 'martian' ),
			'dark'   => __( 'Dark', 'martian' ),
			'custom' => __( 'Custom', 'martian' ),
		),
		'section'  => 'colors',
		'priority' => 5,
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'colorscheme_hue', array(
		'mode'     => 'hue',
		'section'  => 'colors',
		'priority' => 6,
	) ) );

	/*-----------------------------------------------
	  # Theme Options Panel
	  ---------------------------------------------*/
	$wp_customize->add_panel( 'martian_theme_options', array(
		'title'    => esc_html__( 'Martian Options', 'martian' ),
		'priority' => 130,
	) );

	/**
	 * General Settings
	 */
	$wp_customize->add_section( 'martian_general_settings', array(
		'title' => esc_html__( 'General', 'martian' ),
		'panel' => 'martian_theme_options',
	) );

	// Box Border Layout
	$wp_customize->add_setting( 'martian_general_box_border', array(
		'default'           => false,
		'sanitize_callback' => 'wp_validate_boolean',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_general_box_border', array(
		'type'        => 'checkbox',
		'label'       => esc_html__( 'Box Border Layout', 'martian' ),
		'description' => esc_html__( 'Make the site layout with white box border.', 'martian' ),
		'section'     => 'martian_general_settings',
	) );

	// Blog Settings
	$wp_customize->add_setting( 'martian_title_for_blog', array(
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( new Martian_Customize_Heading_Control( $wp_customize, 'martian_title_for_blog', array(
		'label'   => esc_html__( 'Blog', 'martian' ),
		'section' => 'martian_general_settings',
	) ) );

	$wp_customize->add_setting( 'martian_general_blog_layout', array(
		'default'           => 'standard',
		'transport'         => 'refresh',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'martian_general_blog_layout', array(
		'type'    => 'radio',
		'label'   => __( 'Blog Style', 'martian' ),
		'choices' => array(
			'standard' => __( 'Standard', 'martian' ),
			'grid'     => __( 'Grid', 'martian' ),
		),
		'section' => 'martian_general_settings',
	) );

	/**
	 * Sidebar Settings
	 */
	$wp_customize->add_section( 'martian_sidebar_settings', array(
		'title' => esc_html__( 'Sidebars', 'martian' ),
		'panel' => 'martian_theme_options',
	) );

	// Blog sidebar
	$wp_customize->add_setting( 'martian_sidebar_blog', array(
		'default'           => 'none',
		'transport'         => 'refresh',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'martian_sidebar_blog', array(
		'type'    => 'radio',
		'label'   => __( 'Home & Archive', 'martian' ),
		'choices' => array(
			'none'  => __( 'Disable', 'martian' ),
			'right' => __( 'Left', 'martian' ), // This will make add ad pull-right class to #primary area.
			'left'  => __( 'Right', 'martian' ),  // This will make add ad pull-left class to #primary area.
		),
		'section' => 'martian_sidebar_settings',
	) );

	// Blog single sidebar
	$wp_customize->add_setting( 'martian_sidebar_blog_single', array(
		'default'           => 'none',
		'transport'         => 'refresh',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'martian_sidebar_blog_single', array(
		'type'    => 'radio',
		'label'   => __( 'Single Post', 'martian' ),
		'choices' => array(
			'none'  => __( 'Disable', 'martian' ),
			'right' => __( 'Left', 'martian' ), // This will make add ad pull-right class to #primary area.
			'left'  => __( 'Right', 'martian' ),  // This will make add ad pull-left class to #primary area.
		),
		'section' => 'martian_sidebar_settings',
	) );

	/**
	 * Header Settings
	 */
	$wp_customize->add_section( 'martian_header_settings', array(
		'title' => esc_html__( 'Header', 'martian' ),
		'panel' => 'martian_theme_options',
	) );

	// Transparent header
	$wp_customize->add_setting( 'martian_header_transparent', array(
		'default'           => false,
		'sanitize_callback' => 'wp_validate_boolean',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_header_transparent', array(
		'type'        => 'checkbox',
		'label'       => esc_html__( 'Transparent', 'martian' ),
		'description' => esc_html__( 'Check if you want to make the header transparent.', 'martian' ),
		'section'     => 'martian_header_settings',
	) );

	// Closed header
	$wp_customize->add_setting( 'martian_header_closed', array(
		'default'           => false,
		'sanitize_callback' => 'wp_validate_boolean',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_header_closed', array(
		'type'        => 'checkbox',
		'label'       => esc_html__( 'Closed', 'martian' ),
		'description' => esc_html__( 'Check if you want closed menu items.', 'martian' ),
		'section'     => 'martian_header_settings',
	) );


	// Sticky header
	$wp_customize->add_setting( 'martian_header_sticky', array(
		'default'           => true,
		'sanitize_callback' => 'wp_validate_boolean',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_header_sticky', array(
		'type'        => 'checkbox',
		'label'       => esc_html__( 'Sticky', 'martian' ),
		'description' => esc_html__( 'Check if you want always sticky header.', 'martian' ),
		'section'     => 'martian_header_settings',
	) );

	// Inner Header Settings
	$wp_customize->add_setting( 'martian_title_for_inner_header', array(
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( new Martian_Customize_Heading_Control( $wp_customize, 'martian_title_for_inner_header', array(
		'label'   => esc_html__( 'Inner Header', 'martian' ),
		'section' => 'martian_header_settings',
	) ) );

	$wp_customize->add_setting( 'martian_page_header_enable', array(
		'default'           => true,
		'sanitize_callback' => 'wp_validate_boolean',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_page_header_enable', array(
		'type'        => 'checkbox',
		'label'       => esc_html__( 'Enable', 'martian' ),
		'description' => esc_html__( 'Check if you want to display the page header.', 'martian' ),
		'section'     => 'martian_header_settings',
	) );

	$wp_customize->add_setting( 'martian_page_header_title', array(
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'postMessage',
		'default'           => esc_html__( 'Blog', 'martian' ),
	) );
	$wp_customize->add_control( 'martian_page_header_title', array(
		'type'        => 'text',
		'label'       => esc_html__( 'Default Title', 'martian' ),
		'description' => esc_html__( 'Enter the default title for page header.', 'martian' ),
		'section'     => 'martian_header_settings',
	) );

	$wp_customize->add_setting( 'martian_page_header_desc', array(
		'sanitize_callback' => 'sanitize_textarea_field',
		'transport'         => 'postMessage',
		'default'           => esc_html__( 'Read Recent News From HQ', 'martian' ),
	) );
	$wp_customize->add_control( 'martian_page_header_desc', array(
		'type'        => 'textarea',
		'label'       => esc_html__( 'Description', 'martian' ),
		'description' => esc_html__( 'Enter the description for page header.', 'martian' ),
		'section'     => 'martian_header_settings',
	) );

	$wp_customize->add_setting( 'martian_page_header_image', array(
		'transport'         => 'postMessage',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'martian_page_header_image', array(
		'label'       => esc_html__( 'Default Image', 'martian' ),
		'description' => esc_html__( 'Default background image for the page header.', 'martian' ),
		'section'     => 'martian_header_settings',
	) ) );

	/**
	 * General Settings
	 */
	$wp_customize->add_section( 'martian_portfolio_settings', array(
		'title' => esc_html__( 'Portfolio', 'martian' ),
		'panel' => 'martian_theme_options',
	) );

	// Box Border Layout
	$wp_customize->add_setting( 'martian_portfolio_archive_link', array(
		'sanitize_callback' => 'esc_url_raw',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'martian_portfolio_archive_link', array(
		'type'        => 'text',
		'label'       => esc_html__( 'Portfolio Archive Link', 'martian' ),
		'description' => esc_html__( 'This link will use for next/prev navigation on the single.', 'martian' ),
		'section'     => 'martian_portfolio_settings',
	) );

	/**
	 * Footer Settings
	 */
	$wp_customize->add_section( 'martian_footer_settings', array(
		'title' => esc_html__( 'Footer', 'martian' ),
		'panel' => 'martian_theme_options',
	) );

	// Fixed Footer
	$wp_customize->add_setting( 'martian_footer_fixed', array(
		'default'           => true,
		'sanitize_callback' => 'wp_validate_boolean',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_footer_fixed', array(
		'type'        => 'checkbox',
		'label'       => esc_html__( 'Fixed', 'martian' ),
		'description' => esc_html__( 'Check if you want to make the footer always fixed.', 'martian' ),
		'section'     => 'martian_footer_settings',
	) );

	$copyright_defaults = sprintf(
		esc_html__( '&copy; %1$s %2$s - Designed by %3$s', 'martian' ),
		date( 'Y' ),
		get_bloginfo( 'name' ),
		'<a href="' . esc_url( 'http://www.digitalheaps.com/' ) . '">' . esc_attr( 'DigitalHeaps' ) . '</a>'
	);

	// Copyright Text
	$wp_customize->add_setting( 'martian_footer_copyright', array(
		'default'           => $copyright_defaults,
		'sanitize_callback' => 'martian_sanitize_html_content',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_footer_copyright', array(
		'type'    => 'textarea',
		'label'   => esc_html__( 'Copyright Text', 'martian' ),
		'section' => 'martian_footer_settings',
	) );

	/**
	 * 404 Error
	 */
	$wp_customize->add_section( 'martian_404_settings', array(
		'title' => esc_html__( '404 Error Page', 'martian' ),
		'panel' => 'martian_theme_options',
	) );

	$wp_customize->add_setting( 'martian_404_image', array(
		'transport'         => 'postMessage',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'martian_404_image', array(
		'label'   => esc_html__( 'Background Image', 'martian' ),
		'section' => 'martian_404_settings',
	) ) );

	$wp_customize->add_setting( 'martian_404_code', array(
		'default'           => esc_html__( '404', 'martian' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_404_code', array(
		'type'    => 'text',
		'label'   => esc_html__( 'Error Code', 'martian' ),
		'section' => 'martian_404_settings',
	) );

	// Box Border Layout
	$wp_customize->add_setting( 'martian_404_message', array(
		'default'           => esc_html__( 'Error', 'martian' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'martian_404_message', array(
		'type'    => 'text',
		'label'   => esc_html__( 'Error Message', 'martian' ),
		'section' => 'martian_404_settings',
	) );

	$wp_customize->add_setting( 'martian_404_home', array(
		'default'           => true,
		'sanitize_callback' => 'wp_validate_boolean',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'martian_404_home', array(
		'type'    => 'checkbox',
		'label'   => esc_html__( 'Home Link', 'martian' ),
		'section' => 'martian_404_settings',
	) );

	$wp_customize->add_setting( 'martian_404_back', array(
		'default'           => true,
		'sanitize_callback' => 'wp_validate_boolean',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'martian_404_back', array(
		'type'    => 'checkbox',
		'label'   => esc_html__( 'Back Link', 'martian' ),
		'section' => 'martian_404_settings',
	) );

	/**
	 * Mailchimp API
	 */
	$wp_customize->add_section( 'martian_mchimp_api_settings', array(
		'title' => esc_html__( 'MailChimp API', 'martian' ),
		'panel' => 'martian_theme_options',
	) );

	$wp_customize->add_setting( 'martian_mailchimp_api_key', array(
		'transport'         => 'postMessage',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'martian_mailchimp_api_key', array(
		'type'        => 'text',
		'label'       => esc_html__( 'API Key', 'martian' ),
		'description' => esc_html__( 'Enter the mailchimp api key to use newsletter form. You can get the api here: https://goo.gl/CLVr2h', 'martian' ),
		'section'     => 'martian_mchimp_api_settings',
	) );

	$wp_customize->add_setting( 'martian_mailchimp_api_list', array(
		'transport'         => 'postMessage',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'martian_mailchimp_api_list', array(
		'type'        => 'text',
		'label'       => esc_html__( 'List ID', 'martian' ),
		'description' => esc_html__( 'Enter the mailchimp list id. You can found list here: https://goo.gl/DjFj7p', 'martian' ),
		'section'     => 'martian_mchimp_api_settings',
	) );

}

add_action( 'customize_register', 'martian_customize_register' );

/**
 * Sanitize the page layout options.
 */
function martian_sanitize_page_layout( $input ) {
	$valid = array(
		'one-column' => __( 'One Column', 'martian' ),
		'two-column' => __( 'Two Column', 'martian' ),
	);

	if ( array_key_exists( $input, $valid ) ) {
		return $input;
	}

	return '';
}

/**
 * Sanitize the colorscheme.
 */
function martian_sanitize_colorscheme( $input ) {
	$valid = array( 'light', 'dark', 'custom' );

	if ( in_array( $input, $valid ) ) {
		return $input;
	}

	return 'light';
}

/**
 * Sanitize HTML Text
 */
function martian_sanitize_html_content( $input ) {
	$allowed = array(
		'a'      => array(
			'href'  => array(),
			'title' => array()
		),
		'em'     => array(),
		'strong' => array(),
	);

	return wp_kses( $input, $allowed );
}

/**
 * Render the site title for the selective refresh partial.
 *
 * @since Martian 1.0
 * @see   martian_customize_register()
 *
 * @return void
 */
function martian_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @since Martian 1.0
 * @see   martian_customize_register()
 *
 * @return void
 */
function martian_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Return whether we're previewing the front page and it's a static page.
 */
function martian_is_static_front_page() {
	return ( is_front_page() && ! is_home() );
}

/**
 * Return whether we're on a view that supports a one or two column layout.
 */
function martian_is_view_with_layout_option() {
	// This option is available on all pages. It's also available on archives when there isn't a sidebar.
	return ( is_page() || ( is_archive() && ! is_active_sidebar( 'sidebar-1' ) ) );
}

/**
 * Bind JS handlers to instantly live-preview changes.
 */
function martian_customize_preview_js() {
	wp_enqueue_media();
	wp_enqueue_script( 'martian-customize-preview', get_theme_file_uri( '/assets/js/customize-preview.js' ), array( 'customize-preview' ), '1.0.0', true );
}

add_action( 'customize_preview_init', 'martian_customize_preview_js' );

/**
 * Load dynamic logic for the customizer controls area.
 */
function martian_panels_js() {
	wp_enqueue_style( 'martian-customize-controls', get_theme_file_uri( '/assets/css/customize-controls.css' ), array(), '1.0.0' );
	wp_enqueue_script( 'martian-customize-controls', get_theme_file_uri( '/assets/js/customize-controls.js' ), array(), '1.0.0', true );
}

add_action( 'customize_controls_enqueue_scripts', 'martian_panels_js' );
