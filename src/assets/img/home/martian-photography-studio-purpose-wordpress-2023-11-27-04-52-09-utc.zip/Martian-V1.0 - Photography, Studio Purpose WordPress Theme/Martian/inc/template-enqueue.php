<?php
/**
 * Register and Load Scripts and Styles for Martian
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 */

// Animate.CSS
wp_register_style(
	'animate-css',
	get_theme_file_uri( '/assets/dependencies/animate.css/animate.min.css' ),
	array(),
	'3.5.1'
);

// Auto Hiding Navigation
wp_register_script(
	'auto-hiding-navigation',
	get_theme_file_uri( '/assets/dependencies/auto-hiding-navigation/main.js' ),
	array( 'jquery' ),
	'1.0.0',
	true
);

// Before After
{
	wp_register_style(
		'before-after',
		get_theme_file_uri( '/assets/dependencies/before-after.js/before-after.min.css' ),
		array(),
		'1.0.0'
	);

	wp_register_script(
		'before-after',
		get_theme_file_uri( '/assets/dependencies/before-after.js/before-after.min.js' ),
		array( 'jquery' ),
		'1.0.0',
		true
	);
}

// Bootstrap
{
	wp_register_style(
		'bootstrap',
		get_theme_file_uri( '/assets/dependencies/bootstrap/css/bootstrap.min.css' ),
		array(),
		'3.3.7'
	);

	wp_register_script(
		'bootstrap',
		get_theme_file_uri( '/assets/dependencies/bootstrap/js/bootstrap.min.js' ),
		array( 'jquery' ),
		'3.3.7',
		true
	);
}

// Decent Icons
wp_register_style(
	'dt-icons',
	get_theme_file_uri( '/assets/dependencies/dt-icons/dt-icons.css' ),
	array(),
	'1.0.0'
);

// Font Awesome
wp_register_style(
	'font-awesome',
	get_theme_file_uri( '/assets/dependencies/font-awesome/css/font-awesome.min.css' ),
	array(),
	'1.0.0'
);

// Isotope
wp_register_script(
	'isotope',
	get_theme_file_uri( '/assets/dependencies/isotope/isotope.pkgd.min.js' ),
	array(),
	'2.2.2',
	true
);

// jQuery.parallaxBackground
wp_register_script(
	'jquery-parallax-background',
	get_theme_file_uri( '/assets/dependencies/jQuery.parallaxBackground/jQuery.parallaxBackground.min.js' ),
	array(),
	'1.0.0',
	true
);

// Plyr
{
	wp_register_script(
		'plyr',
		get_theme_file_uri( '/assets/dependencies/plyr/plyr.js' ),
		array(),
		'2.0.12',
		true
	);
	wp_register_style(
		'plyr',
		get_theme_file_uri( '/assets/dependencies/plyr/plyr.css' ),
		array(),
		'2.0.12'
	);
}

// jQuery Appear
wp_register_script(
	'jquery-appear',
	get_theme_file_uri( '/assets/dependencies/jquery.appear.bas2k/jquery.appear.js' ),
	array( 'jquery' ),
	'1.0.0',
	true
);

// jQuery Countdown
wp_register_script(
	'jquery-countdown',
	get_theme_file_uri( '/assets/dependencies/jquery.countdown/jquery.countdown.js' ),
	array( 'jquery' ),
	'2.2.0',
	true
);

// Justified Gallery
{
	wp_register_style(
		'justified-gallery',
		get_theme_file_uri( '/assets/dependencies/justifiedGallery/css/justifiedGallery.min.css' ),
		array(),
		'3.6.3'
	);

	wp_register_script(
		'justified-gallery',
		get_theme_file_uri( '/assets/dependencies/justifiedGallery/jquery.justifiedGallery.min.js' ),
		array( 'jquery' ),
		'3.6.3',
		true
	);
}

// LightGallery
{
	wp_register_style(
		'lightgallery',
		get_theme_file_uri( '/assets/dependencies/lightgallery/css/lightgallery.css' ),
		array(),
		'1.4.0'
	);

	wp_register_script(
		'lightgallery',
		get_theme_file_uri( '/assets/dependencies/lightgallery/js/lightgallery.min.js' ),
		array( 'jquery' ),
		'1.4.0',
		true
	);
}

// Smooth Scroll
wp_register_script(
	'smoothscroll',
	get_theme_file_uri( '/assets/dependencies/smoothscroll/smoothscroll.js' ),
	array(),
	'1.4.6',
	true
);

// Swiper.JS
{
	wp_register_style(
		'swiper',
		get_theme_file_uri( '/assets/dependencies/Swiper/css/swiper.min.css' ),
		array('dt-icons'),
		'3.4.2'
	);

	wp_register_script(
		'swiper',
		get_theme_file_uri( '/assets/dependencies/Swiper/js/swiper.jquery.min.js' ),
		array( 'jquery' ),
		'3.4.2',
		true
	);

	// Runner Addon
	wp_register_script(
		'swiper-runner',
		get_theme_file_uri( '/assets/dependencies/SwiperRunner/SwiperRunner.min.js' ),
		array( 'jquery', 'swiper' ),
		'1.0.0',
		true
	);
}

// WOW.js
wp_register_script(
	'wow',
	get_theme_file_uri( '/assets/dependencies/wow/js/wow.min.js' ),
	array(),
	'1.1.2',
	true
);

// Add custom fonts, used in the main stylesheet.
wp_enqueue_style( 'martian-fonts', martian_fonts_url(), array(), null );

wp_enqueue_style( 'bootstrap' );
wp_enqueue_style( 'font-awesome' );
wp_enqueue_style( 'animate-css' );

// Theme stylesheet.
wp_enqueue_style( 'martian', get_stylesheet_uri() );

// Load the dark colorscheme.
// if ( 'dark' === get_theme_mod( 'colorscheme', 'light' ) || is_customize_preview() ) {
// 	wp_enqueue_style( 'martian-colors-dark', get_theme_file_uri( '/assets/css/colors-dark.css' ), array( 'martian-style' ), '1.0' );
// }


wp_enqueue_script( 'bootstrap' );
wp_enqueue_script( 'martian', get_theme_file_uri( '/assets/js/app.js' ), array( 'jquery' ), '1.0.0', true );
wp_enqueue_script( 'wow' );
wp_localize_script( 'martian', 'martian_ajax', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

// wp_enqueue_script( 'jquery-scrollto', get_theme_file_uri( '/assets/js/jquery.scrollTo.js' ), array( 'jquery' ), '2.1.2', true );

// wp_localize_script( 'martian-skip-link-focus-fix', 'martianScreenReaderText', $martian_l10n );

if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}