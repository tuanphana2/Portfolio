<?php
/**
 * Martian functions and definitions
 *
 * @link       https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 */

/**
 * Martian only works in WordPress 4.7 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.7-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';

	return;
}

/**
 * Load Codestar Framework
 */
require_once get_parent_theme_file_path( '/cs-framework/cs-framework.php' );
// TGMPA
require_once get_parent_theme_file_path( '/tgmpa/init.php' );

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function martian_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/martian
	 * If you're building a theme based on Martian, use a find and replace
	 * to change 'martian' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'martian' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	add_image_size( 'martian-featured-image', 750, 400, true );
	add_image_size( 'martian-carousel-thumb', 250, 220, true );
	add_image_size( 'martian-related-thumb', 270, 290, true );
	add_image_size( 'martian-album-thumb', 480, 445, true );

	// Set the default content width.
	$GLOBALS['content_width'] = 525;

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'main'   => __( 'Main', 'martian' ),
		'social' => __( 'Social Networks', 'martian' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'image',
		'video',
		'quote',
		'link',
		'gallery',
	) );

	// Add theme support for Custom Logo.
	add_theme_support( 'custom-logo', array(
		'width'       => 150,
		'height'      => 50,
		'flex-width'  => true,
		'flex-height' => true
	) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, and column width.
 	 */
	add_editor_style( array( 'assets/css/editor-style.css', martian_fonts_url() ) );

}

add_action( 'after_setup_theme', 'martian_setup' );

/**
 * Run options setups after the theme switched or martian activated.
 */
function martian_setup_options() {
	update_option( 'medium_size_w', 370 );
	update_option( 'medium_size_h', 250 );
	update_option( 'large_size_w', 750 );
	update_option( 'large_size_h', 400 );
}

add_action( 'after_switch_theme', 'martian_setup_options' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function martian_content_width() {

	$content_width = $GLOBALS['content_width'];

	// Get layout.
	$page_layout = get_theme_mod( 'page_layout' );

	// Check if layout is one column.
	if ( 'one-column' === $page_layout ) {
		if ( martian_is_frontpage() ) {
			$content_width = 644;
		} elseif ( is_page() ) {
			$content_width = 740;
		}
	}

	// Check if is single post and there is no sidebar.
	if ( is_single() && ! is_active_sidebar( 'sidebar-1' ) ) {
		$content_width = 740;
	}

	/**
	 * Filter Martian content width of the theme.
	 *
	 * @since Martian 1.0
	 *
	 * @param $content_width integer
	 */
	$GLOBALS['content_width'] = apply_filters( 'martian_content_width', $content_width );
}

add_action( 'template_redirect', 'martian_content_width', 0 );

/**
 * Register custom fonts.
 */
function martian_fonts_url() {
	$fonts_url = '';

	/**
	 * Translators: If there are characters in your language that are not
	 * supported by Libre Franklin, translate this to 'off'. Do not translate
	 * into your own language.
	 */
	$lato   = _x( 'on', 'Lato font: on or off', 'martian' );
	$roboto = _x( 'on', 'Roboto font: on or off', 'martian' );

	$font_families = array();

	if ( 'off' !== $lato ) {

		$font_families[] = 'Lato:400,700,900';
	}

	if ( 'off' !== $roboto ) {

		$font_families[] = 'Roboto:400,700,900';
	}

	if ( ! empty( $font_families ) ) {

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( 'latin,latin-ext' ),
		);

		$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
	}

	return esc_url_raw( $fonts_url );
}

/**
 * Add preconnect for Google Fonts.
 *
 * @since Martian 1.0
 *
 * @param array  $urls          URLs to print for resource hints.
 * @param string $relation_type The relation type the URLs are printed.
 *
 * @return array $urls           URLs to print for resource hints.
 */
function martian_resource_hints( $urls, $relation_type ) {
	if ( wp_style_is( 'martian-fonts', 'queue' ) && 'preconnect' === $relation_type ) {
		$urls[] = array(
			'href' => 'https://fonts.gstatic.com',
			'crossorigin',
		);
	}

	return $urls;
}

add_filter( 'wp_resource_hints', 'martian_resource_hints', 10, 2 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function martian_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'martian' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'martian' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 1', 'martian' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Add widgets here to appear in your footer.', 'martian' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer 2', 'martian' ),
		'id'            => 'sidebar-3',
		'description'   => __( 'Add widgets here to appear in your footer.', 'martian' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}

add_action( 'widgets_init', 'martian_widgets_init' );

/**
 * Display custom color CSS.
 */
function martian_colors_css_wrap() {
	if ( 'custom' !== get_theme_mod( 'colorscheme' ) && ! is_customize_preview() ) {
		return;
	}

	require_once( get_parent_theme_file_path( '/inc/color-patterns.php' ) );
	$hue = absint( get_theme_mod( 'colorscheme_hue', 250 ) );
	?>
	<style type="text/css" id="custom-theme-colors" <?php if ( is_customize_preview() ) {
		echo 'data-hue="' . $hue . '"';
	} ?>>
		<?php echo martian_custom_colors_css(); ?>
	</style>
<?php }

add_action( 'wp_head', 'martian_colors_css_wrap' );

/**
 * Enqueue scripts and styles.
 */
function martian_scripts() {
	require get_parent_theme_file_path( '/inc/template-enqueue.php' );
}

add_action( 'wp_enqueue_scripts', 'martian_scripts' );

function martian_admin_scripts() {
	wp_enqueue_style( 'martian-admin-style', get_parent_theme_file_uri( 'assets/css/admin.css' ), array(), '1.0.0' );
}

add_action( 'admin_enqueue_scripts', 'martian_admin_scripts' );

/**
 * Custom template tags for this theme.
 */
require get_parent_theme_file_path( '/inc/template-tags.php' );

/**
 * Additional features to allow styling of the templates.
 */
require get_parent_theme_file_path( '/inc/template-functions.php' );

/**
 * Customizer additions.
 */
require get_parent_theme_file_path( '/inc/customizer.php' );

/**
 * Martian Menu Walker.
 */
require get_parent_theme_file_path( '/inc/martian-menu-walker.php' );
