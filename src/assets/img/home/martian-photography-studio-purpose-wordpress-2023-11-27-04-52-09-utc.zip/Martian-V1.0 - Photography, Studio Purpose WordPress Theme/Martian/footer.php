<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link       https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.2
 */

?>

		</div><!-- #content -->

	</div><!-- .site-content-contain -->
</div><!-- #site -->

<footer id="site-footer">
	<div class="container-fluid">
		<div class="site-info pull-left">
			<p>
				<?php
				$default = sprintf(
					esc_html__( '&copy; %1$s %2$s - Designed by %3$s', 'martian' ),
					date( 'Y' ),
					get_bloginfo( 'name' ),
					'<a href="' . esc_url( 'http://www.digitalheaps.com/' ) . '">' . esc_attr( 'DigitalHeaps' ) . '</a>'
				);
				echo wp_kses_post( get_theme_mod( 'martian_footer_copyright', $default ) );
				?>
			</p>
		</div><!-- .site-info -->

		<?php
		if ( has_nav_menu( 'social' ) ) {
			wp_nav_menu( array(
				'theme_location' => 'social',
				'container'      => false,
				'depth'          => 1,
				'link_before'    => '<span class="sr-only">',
				'link_after'     => '</span>',
				'menu_class'     => 'footer-social-link pull-right',
				'walker'         => new Martian_Menu_Walker()
			) );
		}
		?>
	</div><!-- /.container-fluid -->
</footer><!-- /#site-footer -->
<div id="site-footer-mask"></div>

<?php wp_footer(); ?>

</body>
</html>
