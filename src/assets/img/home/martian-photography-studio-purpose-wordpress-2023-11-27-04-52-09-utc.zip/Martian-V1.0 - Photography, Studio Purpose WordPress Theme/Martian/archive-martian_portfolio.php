<?php
/**
 * The template for displaying archive pages
 *
 * @link       https://codex.wordpress.org/Template_Hierarchy
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.0
 */

$layout  = get_theme_mod( 'martian_general_blog_layout', 'standard' );
$sidebar = get_theme_mod( 'martian_sidebar_blog', 'none' );

$mainColumn = 'col-md-12';
if ( $sidebar !== 'none' ) {
	$mainColumn = 'col-md-9 pull-' . $sidebar;
}
get_header(); ?>

	<div class="wrap inner-pages-container">
		<div class="container">
			<div class="row">
				<div id="primary" class="<?php echo esc_attr( $mainColumn ); ?> content-area">
					<main id="main" class="site-main martian-posts-archives">

						<?php if ( have_posts() ) : ?>
							<div class="row martian-portfolio-grid">
								<?php while ( have_posts() ) : the_post(); ?>
									<div class="col-md-3 col-sm-6">
										<div class="martian-portfolio-thumb standard portfolio-<?php the_ID(); ?>">
											<?php
											if ( has_post_thumbnail() ) {
												the_post_thumbnail( 'martian-album-thumb' );
											} else {
												echo '<img src="'. get_parent_theme_file_uri('assets/img/portfolio-mask-square.jpg') . '" alt="">';
											}
											?>

											<div class="caption">
												<div class="caption-content">
													<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
													</h3>
													<?php
													$terms = get_the_terms( get_the_ID(), 'martian_portfolio_cat' );
													if ( $terms && ! is_wp_error( $terms ) ) :

														$items = array();
														foreach ( $terms as $term ) {
															$items[] = $term->name;
														}
														$termsString = implode( " / ", $items );
														?>

														<div class="categories">
															<?php echo esc_html( $termsString ); ?>
														</div>
													<?php endif; ?>

													<div class="links">
														<a href="<?php the_permalink(); ?>"><i
																	class="fa fa-link"></i></a>
														<?php if ( has_post_thumbnail() ) : ?>
															<a href="<?php the_post_thumbnail_url( 'full' ); ?>"
															   class="viewLightbox"><i
																		class="fa fa-arrows-alt"></i></a>
														<?php endif; ?>
													</div>

												</div>
											</div>
										</div>
									</div>
								<?php endwhile; ?>
							</div>
							<?php the_posts_pagination( array(
								'prev_text'          => '<i class="fa fa-arrow-left"></i><span class="screen-reader-text">' . __( 'Previous page', 'martian' ) . '</span>',
								'next_text'          => '<span class="screen-reader-text">' . __( 'Next page', 'martian' ) . '</span><i
								class="fa fa-arrow-right"></i>',
								'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'martian' ) . ' </span>',
							) );

						else :

							get_template_part( 'template-parts/post/content', 'none' );

						endif; ?>

					</main><!-- #main -->
				</div><!-- #primary -->

				<?php if ( $sidebar !== 'none' ) : ?>
					<div class="col-md-3">
						<?php get_sidebar(); ?>
					</div><!-- /.col-md-3 -->
				<?php endif; ?>
			</div><!-- /.row -->
		</div><!-- /.container -->
	</div><!-- .wrap -->

<?php get_footer();
