<?php if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options = array();

// -----------------------------------------
// Post Type Options                       -
// -----------------------------------------
$options[] = array(
	'id'        => '_martian_post_format_options',
	'title'     => esc_html__( 'Post Format Options', 'martian' ),
	'post_type' => 'post',
	'context'   => 'normal',
	'priority'  => 'high',
	'sections'  => array(

		array(
			'name'   => 'martian_post_image_gallery',
			'fields' => array(

				// Gallery or Image
				array(
					'type'    => 'subheading',
					'content' => esc_html__( 'Image/Gallery', 'martian' )
				),
				array(
					'id'    => 'images',
					'type'  => 'gallery',
					'title' => esc_html__( 'Images', 'martian' ),
					'desc'  => esc_html__( 'You must upload 3 images.', 'martian' )
				),

				// Quote
				array(
					'type'    => 'subheading',
					'content' => esc_html__( 'Quote', 'martian' )
				),
				array(
					'id'    => 'quote',
					'type'  => 'textarea',
					'title' => esc_html__( 'Content', 'martian' ),
				),
				array(
					'id'    => 'quote_author',
					'type'  => 'text',
					'title' => esc_html__( 'Author', 'martian' ),
				),
				array(
					'id'    => 'quote_source',
					'type'  => 'text',
					'title' => esc_html__( 'Source Link', 'martian' ),
				),

			),
		)

	),
);

// Custom Cover
$options[] = array(
	'id'        => '_martian_post_cover',
	'title'     => esc_html__( 'Custom Cover', 'martian' ),
	'post_type' => array( 'post', 'martian_portfolio' ),
	'context'   => 'side',
	'priority'  => 'default',
	'sections'  => array(

		array(
			'name'   => 'martian_cover',
			'fields' => array(

				array(
					'id'    => 'image',
					'type'  => 'image',
					'title' => esc_html__( 'Thumbnail Image', 'martian' ),
				),

				array(
					'type'    => 'notice',
					'class'   => 'info',
					'content' => esc_html__( 'THIS SETTINGS FOR ONLY GRID & MASONRY STYLE POST. Will use featured image if not uploaded any image here.', 'martian' ),
				),

			),
		)

	),
);

// -----------------------------------------
// Page & Post Metabox Options             -
// -----------------------------------------
$options[] = array(
	'id'        => '_martian_page_options',
	'title'     => esc_html__( 'Visibility Settings', 'martian' ),
	'post_type' => array( 'post', 'page', 'martian_portfolio', 'martian_gallery' ),
	'context'   => 'normal',
	'priority'  => 'default',
	'sections'  => array(

		array(
			'name'   => 'martian_page_header',
			'title'  => esc_html__( 'Page Header', 'martian' ),
			'fields' => array(

				array(
					'id'      => 'page_header_global',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Use Global Settings', 'martian' ),
					'default' => true,
				),

				array(
					'id'         => 'page_header',
					'type'       => 'switcher',
					'title'      => esc_html__( 'Page Header', 'martian' ),
					'default'    => true,
					'dependency' => array( 'page_header_global', '!=', 'true' ),
				),

				array(
					'id'         => 'header_image',
					'type'       => 'image',
					'title'      => esc_html__( 'Header Image', 'martian' ),
					'dependency' => array( 'page_header_global', '!=', 'true' ),
					'desc'       => esc_html__( 'Default: Featured image, if fail will get image from global settings.', 'martian' ),
				),

				array(
					'id'         => 'custom_title',
					'type'       => 'text',
					'title'      => esc_html__( 'Title', 'martian' ),
					'dependency' => array( 'page_header_global', '!=', 'true' ),
					'desc'       => esc_html__( 'Set custom title for the page header. Default: The post title.', 'martian' ),
				),

				array(
					'id'         => 'custom_description',
					'type'       => 'textarea',
					'title'      => esc_html__( 'Description', 'martian' ),
					'dependency' => array( 'page_header_global', '!=', 'true' ),
					'desc'       => esc_html__( 'Set custom description for the page header.', 'martian' ),
				),

			),
		),

		array(
			'name'   => 'martian_page_override',
			'title'  => esc_html__( 'Others', 'martian' ),
			'fields' => array(

				array(
					'id'      => 'transparent_header',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Transparent Header', 'martian' ),
					'default' => false,
				),

				array(
					'id'      => 'footer_mask_fix',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Footer Mask Disable', 'martian' ),
					'default' => false,
				),

				array(
					'id'      => 'box_layout',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Make Boxed Layout', 'martian' ),
					'default' => false,
				),

			),
		),


	),
);

CSFramework_Metabox::instance( $options );
