<?php
/**
 * The template for displaying all single posts
 *
 * @link       https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package    WordPress
 * @subpackage Martian
 * @since      1.0
 * @version    1.0
 */
$sidebar = get_theme_mod( 'martian_sidebar_blog_single', 'none' );

$mainColumn = 'col-md-12';
if ( $sidebar !== 'none' ) {
	$mainColumn = 'col-md-9 pull-' . $sidebar;
}
get_header(); ?>

	<div class="wrap inner-pages-container">
		<div class="container">
			<div class="singlePostNavigation">
				<?php
				$prevPostTitle = esc_html__( 'Previous', 'martian' );
				$prevMarkup    = '<i class="fa fa-long-arrow-left" aria-hidden="true"></i><span>' . $prevPostTitle . '</span>';
				$nextPostTitle = esc_html__( 'Next', 'martian' );
				$nextMarkup    = '<span>' . $nextPostTitle . '</span><i class="fa fa-long-arrow-right" aria-hidden="true"></i>';
				$homeURL       = get_home_url();

				if ( 'page' == get_option( 'show_on_front' ) && ! empty( get_option( 'page_for_posts' ) ) ) {
					$homeURL = get_permalink( get_option( 'page_for_posts' ) );
				}

				// Prev
				echo '<div class="prev">';
				previous_post_link( '%link', $prevMarkup );
				echo '</div>';

				// Home
				echo '<div class="home">';
				echo '<a href="' . esc_url( $homeURL ) . '" title="' . esc_attr__( 'Back to archive', 'martian' ) . '"><i class="fa fa-th" aria-hidden="true"></i></a>';
				echo '</div>';

				// Next
				echo '<div class="next">';
				next_post_link( '%link', $nextMarkup );
				echo '</div>';

				?>
			</div><!-- /.singlePostPagination -->
			<div class="row">
				<div id="primary" class="<?php echo esc_attr( $mainColumn ); ?> content-area">
					<main id="main" class="site-main">

						<?php
						/* Start the Loop */
						while ( have_posts() ) : the_post();

							get_template_part( 'template-parts/post/content', get_post_format() );
							get_template_part( 'template-parts/post/content', 'bio' );

							// If comments are open or we have at least one comment, load up the comment template.
							if ( comments_open() || get_comments_number() ) :
								comments_template();
							endif;

							the_post_navigation( array(
								'prev_text' => '<span class="screen-reader-text">' . esc_html__( 'Previous Post', 'martian' ) . '</span><span class="nav-title"><i class="fa fa-long-arrow-left"></i>%title</span>',
								'next_text' => '<span class="screen-reader-text">' . esc_html__( 'Next Post', 'martian' ) . '</span><span class="nav-title">%title<i class="fa fa-long-arrow-right"></i></span>',
							) );

							// Related Post
							if ( 'post' === get_post_type() ) :
								?>
								<div class="martian-related-posts">
									<div class="martian-section-heading">
										<div class="content">
											<div class="sub-title"><?php esc_html_e( 'You may like this', 'martian' ); ?></div>
											<h2 class="title"><?php esc_html_e( 'Related Posts', 'martian' ); ?></h2>
										</div>
									</div>
									<?php martian_related_posts(); ?>
								</div>
							<?php endif;

						endwhile; // End of the loop.
						?>
					</main><!-- #main -->
				</div><!-- #primary -->

				<?php if ( $sidebar !== 'none' ) : ?>
					<div class="col-md-3">
						<?php get_sidebar(); ?>
					</div><!-- /.col-md-3 -->
				<?php endif; ?>
			</div><!-- /.row -->
		</div><!-- /.container -->
	</div><!-- .wrap -->

<?php get_footer();
